#include<bits/stdc++.h>
using namespace std;

const int N = 405;
int n, m, dist[N];
bool rail[N][N];      // rail[u][v]=true 表示 u、v 之间有铁路

int main(){
    cin >> n >> m;
    for(int i = 1; i <= m; i++){
        int u, v;
        cin >> u >> v;
        rail[u][v] = rail[v][u] = true;
    }

    // 1 和 n 之间必有一条边（铁路或公路），走这条边的车 1 小时直达，
    // 只需给另一辆车在它自己的图上跑 BFS，两车不可能在中途相遇
    bool useRail = !rail[1][n];   // true 表示需要 BFS 的是铁路图

    memset(dist, -1, sizeof dist);
    queue<int> q;
    dist[1] = 0;
    q.push(1);
    while(!q.empty()){
        int u = q.front();
        q.pop();
        for(int v = 1; v <= n; v++){      // 补图不显式建边，直接枚举所有点
            if(v == u || dist[v] != -1) continue;
            bool hasEdge = useRail ? rail[u][v] : !rail[u][v];
            if(!hasEdge) continue;
            dist[v] = dist[u] + 1;
            q.push(v);
        }
    }

    cout << dist[n] << '\n';    // 不可达时 dist[n] 仍是 -1，直接输出
    return 0;
}
