#include<bits/stdc++.h>
using namespace std;

const int LIMIT = 20000;    // 状态上界：m <= 1e4，乘 2 超过 2m 一定不划算
int dist[LIMIT + 5];

int main(){
    int start, target;
    cin >> start >> target;

    memset(dist, -1, sizeof dist);   // -1 表示还没到达过
    queue<int> q;
    dist[start] = 0;
    q.push(start);

    while(!q.empty()){
        int cur = q.front();
        q.pop();
        if(cur == target) break;          // 第一次到达 = 最少按键数

        int doubled = cur * 2;            // 红键：乘 2
        int minusOne = cur - 1;           // 蓝键：减 1
        if(doubled <= LIMIT && dist[doubled] == -1){
            dist[doubled] = dist[cur] + 1;
            q.push(doubled);
        }
        if(minusOne >= 1 && dist[minusOne] == -1){   // 数字必须保持正数
            dist[minusOne] = dist[cur] + 1;
            q.push(minusOne);
        }
    }

    cout << dist[target] << '\n';
    return 0;
}
