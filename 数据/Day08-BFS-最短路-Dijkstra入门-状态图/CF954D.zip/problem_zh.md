# CF954D · Fight Against Traffic

- 难度：1600
- 标签：dfs and similar、graphs、shortest paths
- 链接：https://codeforces.com/problemset/problem/954/D
- 时间限制：1 second　内存限制：256 megabytes
- 出现位置：Day08-BFS-最短路-Dijkstra入门-状态图

## 中文题意

以下为官方英文题意（课堂讲解时请要求学生能用自己的话复述条件与目标）。

Little town Nsk consists of n junctions connected by m bidirectional roads. Each road connects two distinct junctions and no two roads connect the same pair of junctions. It is possible to get from any junction to any other junction by these roads. The distance between two junctions is equal to the minimum possible number of roads on a path between them.
In order to improve the transportation system, the city council asks mayor to build one new road. The problem is that the mayor has just bought a wonderful new car and he really enjoys a ride from his home, located near junction s to work located near junction t. Thus, he wants to build a new road in such a way that the distance between these two junctions won't decrease. 
You are assigned a task to compute the number of pairs of junctions that are not connected by the road, such that if the new road between these two junctions is built the distance between s and t won't decrease.


## 输入格式（中文）

The firt line of the input contains integers n, m, s and t (2 ≤ n ≤ 1000, 1 ≤ m ≤ 1000, 1 ≤ s, t ≤ n, s ≠ t) — the number of junctions and the number of roads in Nsk, as well as the indices of junctions where mayors home and work are located respectively. The i-th of the following m lines contains two integers ui and vi (1 ≤ ui, vi ≤ n, ui ≠ vi), meaning that this road connects junctions ui and vi directly. It is guaranteed that there is a path between any two junctions and no two roads connect the same pair of junctions.


## 输出格式（中文）

Print one integer — the number of pairs of junctions not connected by a direct road, such that building a road between these two junctions won't decrease the distance between junctions s and t.

## 样例

### 样例 1

输入：

```text
5 4 1 5
1 2
2 3
3 4
4 5
```

输出：

```text
0
```

### 样例 2

输入：

```text
5 4 3 5
1 2
2 3
3 4
4 5
```

输出：

```text
5
```

### 样例 3

输入：

```text
5 6 1 5
1 2
1 3
1 4
4 5
3 5
2 5
```

输出：

```text
3
```