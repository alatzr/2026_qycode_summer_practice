#include<bits/stdc++.h>
using namespace std;

const int N = 1005;
int n, m, src, dst;
bool adj[N][N];
vector<int> graph[N];
int distS[N], distT[N];

void bfs(int start, int dist[]){
    for(int i = 1; i <= n; i++) dist[i] = -1;
    queue<int> q;
    dist[start] = 0;
    q.push(start);
    while(!q.empty()){
        int u = q.front();
        q.pop();
        for(int v : graph[u])
            if(dist[v] == -1){
                dist[v] = dist[u] + 1;
                q.push(v);
            }
    }
}

int main(){
    cin >> n >> m >> src >> dst;
    for(int i = 1; i <= m; i++){
        int u, v;
        cin >> u >> v;
        adj[u][v] = adj[v][u] = true;
        graph[u].push_back(v);
        graph[v].push_back(u);
    }

    bfs(src, distS);              // distS[x]：s 到 x 的最短距离
    bfs(dst, distT);              // distT[x]：t 到 x 的最短距离
    int shortest = distS[dst];

    int ans = 0;
    for(int u = 1; u <= n; u++)
        for(int v = u + 1; v <= n; v++){    // 枚举 u<v 避免无向边重复计数
            if(adj[u][v]) continue;         // 只统计原本没有直接道路的点对
            // 新边两个方向都不能让 s->t 变短
            if(distS[u] + 1 + distT[v] >= shortest &&
               distS[v] + 1 + distT[u] >= shortest)
                ans++;
        }
    cout << ans << '\n';
    return 0;
}
