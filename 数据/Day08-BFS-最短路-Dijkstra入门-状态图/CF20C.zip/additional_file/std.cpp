#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<ll,int> Node;    // (距离, 点编号)

const int N = 1e5 + 5;
const ll INF = 1e18;
int n, m, pre[N];             // pre[v]：最短路上 v 的前驱，用于还原路径
ll dist[N];
bool vis[N];
vector<pair<int,int>> graph[N];   // graph[u] = {(v, w), ...}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cin >> n >> m;
    for(int i = 1; i <= m; i++){
        int u, v, w;
        cin >> u >> v >> w;
        graph[u].push_back({v, w});
        graph[v].push_back({u, w});
    }

    // 边权最大 1e6、点数 1e5，路径和可达 1e11，必须 long long
    for(int i = 1; i <= n; i++) dist[i] = INF;
    priority_queue<Node, vector<Node>, greater<Node>> heap;
    dist[1] = 0;
    heap.push({0, 1});
    while(!heap.empty()){
        int u = heap.top().second;
        heap.pop();
        if(vis[u]) continue;      // 旧记录：u 的最短路早已确定
        vis[u] = true;
        for(auto [v, w] : graph[u])
            if(dist[u] + w < dist[v]){
                dist[v] = dist[u] + w;
                pre[v] = u;       // 记录前驱
                heap.push({dist[v], v});
            }
    }

    if(dist[n] == INF){
        cout << -1 << '\n';
        return 0;
    }
    vector<int> path;
    for(int cur = n; cur != 0; cur = pre[cur])   // 从 n 沿前驱走回 1（pre[1]=0 结束）
        path.push_back(cur);
    reverse(path.begin(), path.end());
    for(int i = 0; i < (int)path.size(); i++)
        cout << path[i] << (i + 1 < (int)path.size() ? ' ' : '\n');
    return 0;
}
