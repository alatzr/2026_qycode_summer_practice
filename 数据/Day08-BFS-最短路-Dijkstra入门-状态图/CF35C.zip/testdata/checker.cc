#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;

// 35C 多解校验：参赛输出的格子必须在网格内，且其“最晚起火”距离等于全图最大。
int main(int argc, char* argv[]){
    registerTestlibCmd(argc, argv);
    int n = inf.readInt(), m = inf.readInt();
    int k = inf.readInt();
    vector<vector<int>> dist(n + 1, vector<int>(m + 1, -1));
    queue<pair<int,int>> q;
    for(int i = 0; i < k; i++){
        int x = inf.readInt(), y = inf.readInt();
        if(dist[x][y] == -1){ dist[x][y] = 0; q.push({x, y}); }
    }
    int dx[4] = {1, -1, 0, 0}, dy[4] = {0, 0, 1, -1};
    while(!q.empty()){
        auto [x, y] = q.front(); q.pop();
        for(int d = 0; d < 4; d++){
            int nx = x + dx[d], ny = y + dy[d];
            if(nx < 1 || nx > n || ny < 1 || ny > m || dist[nx][ny] != -1) continue;
            dist[nx][ny] = dist[x][y] + 1;
            q.push({nx, ny});
        }
    }
    int best = 0;
    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= m; j++)
            best = max(best, dist[i][j]);
    int px = ouf.readInt(), py = ouf.readInt();
    if(px < 1 || px > n || py < 1 || py > m)
        quitf(_wa, "coords out of range: %d %d", px, py);
    if(dist[px][py] != best)
        quitf(_wa, "cell (%d,%d) dist=%d, expected max=%d", px, py, dist[px][py], best);
    quitf(_ok, "cell dist=%d = max", best);
}
