#include<bits/stdc++.h>
using namespace std;

// 多源 BFS：所有起火点距离 0 一起入队，求距离最大的格子（任意一个）。
// 原题为文件 IO，此处改标准输入输出以适配 Hydro 判题。
const int N = 2005;
int rows, cols, k;
int dist[N][N];
int dx[4] = {1, -1, 0, 0};
int dy[4] = {0, 0, 1, -1};

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cin >> rows >> cols >> k;
    memset(dist, -1, sizeof dist);
    queue<pair<int,int>> q;
    for(int i = 0; i < k; i++){
        int x, y; cin >> x >> y;
        if(dist[x][y] == -1){ dist[x][y] = 0; q.push({x, y}); }
    }
    while(!q.empty()){
        auto [x, y] = q.front(); q.pop();
        for(int d = 0; d < 4; d++){
            int nx = x + dx[d], ny = y + dy[d];
            if(nx < 1 || nx > rows || ny < 1 || ny > cols || dist[nx][ny] != -1) continue;
            dist[nx][ny] = dist[x][y] + 1;
            q.push({nx, ny});
        }
    }
    int bx = 1, by = 1;
    for(int i = 1; i <= rows; i++)
        for(int j = 1; j <= cols; j++)
            if(dist[i][j] > dist[bx][by]){ bx = i; by = j; }
    cout << bx << ' ' << by << '\n';
    return 0;
}
