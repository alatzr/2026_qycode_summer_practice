#include<bits/stdc++.h>
using namespace std;

const int N = 2e5 + 5;
int n, seq[N], pos[N];
vector<int> graph[N];
bool vis[N];

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cin >> n;
    for(int i = 1; i < n; i++){
        int u, v;
        cin >> u >> v;
        graph[u].push_back(v);
        graph[v].push_back(u);
    }
    for(int i = 1; i <= n; i++){
        cin >> seq[i];
        pos[seq[i]] = i;      // 每个点在给定序列中出现的位置
    }

    // 把每个点的邻居按“给定序列中的位置”排序，逼 BFS 按目标顺序扩展
    for(int i = 1; i <= n; i++)
        sort(graph[i].begin(), graph[i].end(), [](int lhs, int rhs){
            return pos[lhs] < pos[rhs];
        });

    vector<int> order;
    queue<int> q;
    vis[1] = true;
    q.push(1);
    while(!q.empty()){
        int u = q.front();
        q.pop();
        order.push_back(u);
        for(int v : graph[u])
            if(!vis[v]){
                vis[v] = true;
                q.push(v);
            }
    }

    for(int i = 1; i <= n; i++)
        if(order[i - 1] != seq[i]){       // 模拟结果与给定序列逐位比较
            cout << "No\n";
            return 0;
        }
    cout << "Yes\n";
    return 0;
}
