#include<bits/stdc++.h>
using namespace std;

#define ll long long

const int N = 1e5 + 10;
const ll MOD = 1e9 + 7;

int fa[N], sz[N];

int find(int x)
{
	if (fa[x] == x) return x;
	return fa[x] = find(fa[x]); // 路径压缩
}

void merge(int x, int y)
{
	x = find(x), y = find(y);
	if (x == y) return;
	if (sz[x] < sz[y]) swap(x, y); // 按大小合并：小块挂到大块
	fa[y] = x;
	sz[x] += sz[y];
}

ll qmi(ll base, ll expo) // 快速幂：base^expo % MOD
{
	ll res = 1;
	base %= MOD;
	while (expo)
	{
		if (expo & 1) res = res * base % MOD;
		base = base * base % MOD;
		expo >>= 1;
	}
	return res;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	ll k;
	cin >> n >> k;
	for (int i = 1; i <= n; i++)
		fa[i] = i, sz[i] = 1;

	for (int i = 1; i < n; i++)
	{
		int u, v, color;
		cin >> u >> v >> color;
		if (color == 0) merge(u, v); // 只合并红边（非黑边）
	}

	ll bad = 0; // 坏方案：k 个点全落在同一个红边连通块
	for (int i = 1; i <= n; i++)
		if (find(i) == i)
			bad = (bad + qmi(sz[i], k)) % MOD;

	ll ans = ((qmi(n, k) - bad) % MOD + MOD) % MOD; // 减法后补 MOD 防负数
	cout << ans << endl;
	return 0;
}
