#include<bits/stdc++.h>
using namespace std;

const int N = 110;

int fa[N], sz[N];

int find(int x)
{
	if (fa[x] == x) return x;
	return fa[x] = find(fa[x]); // 路径压缩
}

void merge(int x, int y)
{
	x = find(x), y = find(y);
	if (x == y) return;
	if (sz[x] < sz[y]) swap(x, y); // 按大小合并：小块挂到大块
	fa[y] = x;
	sz[x] += sz[y];
}

int main()
{
	int n, m;
	cin >> n >> m;
	for (int i = 1; i <= n; i++)
		fa[i] = i, sz[i] = 1;

	for (int i = 1; i <= m; i++)
	{
		int u, v;
		cin >> u >> v;
		merge(u, v);
	}

	int comp = 0; // 连通块个数
	for (int i = 1; i <= n; i++)
		if (find(i) == i)
			comp++;

	// 连通且 m == n：恰好一个环挂着若干棵树
	if (m == n && comp == 1) cout << "FHTAGN!" << endl;
	else cout << "NO" << endl;
	return 0;
}
