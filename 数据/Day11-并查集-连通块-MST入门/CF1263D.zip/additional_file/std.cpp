#include<bits/stdc++.h>
using namespace std;

const int LETTER = 26;

int fa[LETTER + 5], sz[LETTER + 5];
bool used[LETTER + 5];

int find(int x)
{
	if (fa[x] == x) return x;
	return fa[x] = find(fa[x]); // 路径压缩
}

void merge(int x, int y)
{
	x = find(x), y = find(y);
	if (x == y) return;
	if (sz[x] < sz[y]) swap(x, y); // 按大小合并：小块挂到大块
	fa[y] = x;
	sz[x] += sz[y];
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	cin >> n;
	for (int i = 0; i < LETTER; i++)
		fa[i] = i, sz[i] = 1;

	for (int i = 1; i <= n; i++)
	{
		string pwd;
		cin >> pwd;
		int firstLetter = pwd[0] - 'a';
		for (char ch : pwd)
		{
			int letter = ch - 'a';
			used[letter] = true;
			merge(firstLetter, letter); // 同一个密码里的字母连成一块
		}
	}

	set<int> roots;
	for (int letter = 0; letter < LETTER; letter++)
		if (used[letter])
			roots.insert(find(letter));

	cout << roots.size() << endl;
	return 0;
}
