#include<bits/stdc++.h>
using namespace std;

const int N = 4e5 + 10; // 下标 1..n 给 F 的并查集，n+1..2n 给 G 的并查集

int fa[N], sz[N];
int n, mF, mG;

int find(int x)
{
	if (fa[x] == x) return x;
	return fa[x] = find(fa[x]); // 路径压缩
}

void merge(int x, int y)
{
	x = find(x), y = find(y);
	if (x == y) return;
	if (sz[x] < sz[y]) swap(x, y); // 按大小合并：小块挂到大块
	fa[y] = x;
	sz[x] += sz[y];
}

void solve()
{
	cin >> n >> mF >> mG;
	for (int i = 1; i <= 2 * n; i++)
		fa[i] = i, sz[i] = 1;

	vector<pair<int, int>> edgeF(mF);
	for (auto &[u, v] : edgeF)
		cin >> u >> v;
	for (int i = 1; i <= mG; i++)
	{
		int u, v;
		cin >> u >> v;
		merge(u + n, v + n); // 先建好 G 的连通块（目标结构）
	}

	long long ops = 0;
	for (auto [u, v] : edgeF)
	{
		if (find(u + n) != find(v + n)) ops++; // 跨 G 块的 F 边必须删除
		else merge(u, v);                      // 块内的 F 边保留，参与 F 的连通块
	}

	int rootsF = 0, rootsG = 0;
	for (int i = 1; i <= n; i++)
		if (find(i) == i) rootsF++;
	for (int i = n + 1; i <= 2 * n; i++)
		if (find(i) == i) rootsG++;

	ops += rootsF - rootsG; // 每个 G 块内 F 碎成 p 片就补 p-1 条边
	cout << ops << '\n';
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int T;
	cin >> T;
	while (T--)
		solve();
	return 0;
}
