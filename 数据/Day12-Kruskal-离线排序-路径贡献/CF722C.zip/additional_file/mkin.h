#!/usr/bin/env python3
"""Deterministic test generator for CF722C Destroying Array."""

import random
from pathlib import Path


LIMIT = 100_000
ROOT = Path(__file__).resolve().parent
OUT = ROOT / "inputs"


def write_case(index, values, order):
    n = len(values)
    assert 1 <= n <= LIMIT
    assert len(order) == n and sorted(order) == list(range(1, n + 1))
    assert all(0 <= x <= 10**9 for x in values)
    text = [str(n), " ".join(map(str, values)), " ".join(map(str, order))]
    (OUT / f"{index}.in").write_text("\n".join(text) + "\n", encoding="ascii")


def center_out(n):
    order = []
    left = (n + 1) // 2
    right = left + 1
    while left >= 1 or right <= n:
        if left >= 1:
            order.append(left)
            left -= 1
        if right <= n:
            order.append(right)
            right += 1
    return order


def main():
    rng = random.Random(7_222_026)
    OUT.mkdir(parents=True, exist_ok=True)
    for old in OUT.glob("*.in"):
        old.unlink()

    tests = [
        ([1, 3, 2, 5], [3, 4, 1, 2]),
        ([0], [1]),
        ([10**9], [1]),
        ([0] * 5, [5, 1, 3, 2, 4]),
        (list(range(1, 7)), list(range(1, 7))),
        ([10] * 7, [4, 2, 6, 1, 3, 5, 7]),
        ([10**9] * 6, [3, 4, 2, 5, 1, 6]),
        ([0, 10**9, 0, 10**9, 0, 10**9, 0], [2, 6, 4, 1, 3, 5, 7]),
    ]
    for _ in range(4):
        n = rng.randint(2, 16)
        values = [rng.randint(0, 30) for _ in range(n)]
        order = list(range(1, n + 1))
        rng.shuffle(order)
        tests.append((values, order))

    index = 1
    for values, order in tests:
        write_case(index, values, order)
        index += 1

    n = 2_000
    values = [rng.randint(0, 10**9) for _ in range(n)]
    order = list(range(1, n + 1))
    rng.shuffle(order)
    write_case(index, values, order)
    index += 1

    n = 10_000
    write_case(index, list(range(1, n + 1)), list(range(n, 0, -1)))
    index += 1

    n = LIMIT
    write_case(index, [10**9] * n, list(range(1, n + 1)))
    index += 1
    write_case(index, [1] * n, center_out(n))
    index += 1

    values = [0 if i % 2 == 0 else 10**9 for i in range(n)]
    order = list(range(1, n + 1))
    rng.shuffle(order)
    write_case(index, values, order)
    index += 1

    values = [rng.randint(0, 10**9) for _ in range(n)]
    order = list(range(1, n + 1))
    rng.shuffle(order)
    write_case(index, values, order)
    index += 1

    assert index == 19
    print("CF722C generated 18 inputs")


if __name__ == "__main__":
    main()
