#include<bits/stdc++.h>
using namespace std;

#define ll long long

const int N = 1e5 + 10;

int n, fa[N], p[N];
ll a[N], sum[N], ans[N];
bool vis[N];

int find(int x)
{
	if (fa[x] == x) return x;
	return fa[x] = find(fa[x]);
}

void merge(int x, int y)
{
	x = find(x), y = find(y);
	if (x == y) return;
	fa[y] = x;
	sum[x] += sum[y];
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	cin >> n;
	for (int i = 1; i <= n; i++) cin >> a[i];
	for (int i = 1; i <= n; i++) cin >> p[i];

	ll mx = 0;
	for (int i = n; i >= 1; i--)
	{
		ans[i] = mx; // 恢复 p[i] 之前，就是前 i 次删除后的状态
		int x = p[i];
		vis[x] = true;
		fa[x] = x;
		sum[x] = a[x];
		if (x > 1 && vis[x - 1]) merge(x, x - 1);
		if (x < n && vis[x + 1]) merge(x, x + 1);
		mx = max(mx, sum[find(x)]);
	}

	for (int i = 1; i <= n; i++) cout << ans[i] << '\n';
	return 0;
}
