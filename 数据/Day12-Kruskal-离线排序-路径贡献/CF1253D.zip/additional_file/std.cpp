#include<bits/stdc++.h>
using namespace std;

const int N = 2e5 + 10;

int fa[N], sz[N], mx[N]; // mx 只在根上有效：块内最大编号

int find(int x)
{
	if (fa[x] == x) return x;
	return fa[x] = find(fa[x]); // 路径压缩
}

void merge(int x, int y)
{
	x = find(x), y = find(y);
	if (x == y) return;
	if (sz[x] < sz[y]) swap(x, y); // 按大小合并：小块挂到大块
	fa[y] = x;
	sz[x] += sz[y];
	mx[x] = max(mx[x], mx[y]); // 合并时维护块内最大编号
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n, m;
	cin >> n >> m;
	for (int i = 1; i <= n; i++)
		fa[i] = i, sz[i] = 1, mx[i] = i;

	for (int i = 1; i <= m; i++)
	{
		int u, v;
		cin >> u >> v;
		merge(u, v);
	}

	int ans = 0;
	int i = 1;
	while (i <= n)
	{
		int reach = mx[find(i)]; // 当前块必须覆盖到的最右编号
		int j = i + 1;
		while (j <= reach)
		{
			if (find(j) != find(i))
			{
				merge(i, j); // 区间内的外块必须并进来 = 补一条边
				ans++;
				reach = mx[find(i)]; // 并入后覆盖范围可能变大
			}
			j++;
		}
		i = reach + 1; // [i, reach] 已成一块，跳到下一段
	}

	cout << ans << endl;
	return 0;
}
