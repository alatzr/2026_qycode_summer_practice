#!/usr/bin/env python3
"""Deterministic test generator for CF1253D Harmonious Graph."""

import random
from pathlib import Path


LIMIT = 200_000
ROOT = Path(__file__).resolve().parent
OUT = ROOT / "inputs"


def write_case(index, n, edges):
    assert 3 <= n <= LIMIT and 1 <= len(edges) <= LIMIT
    seen = set()
    for u, v in edges:
        assert 1 <= u <= n and 1 <= v <= n and u != v
        key = (min(u, v), max(u, v))
        assert key not in seen
        seen.add(key)
    lines = [f"{n} {len(edges)}"]
    lines.extend(f"{u} {v}" for u, v in edges)
    (OUT / f"{index}.in").write_text("\n".join(lines) + "\n", encoding="ascii")


def random_edges(rng, n, m):
    edges = set()
    while len(edges) < m:
        u, v = rng.sample(range(1, n + 1), 2)
        edges.add((min(u, v), max(u, v)))
    result = sorted(edges)
    rng.shuffle(result)
    return result


def main():
    rng = random.Random(12_532_026)
    OUT.mkdir(parents=True, exist_ok=True)
    for old in OUT.glob("*.in"):
        old.unlink()

    tests = [
        (14, [(1, 2), (2, 7), (3, 4), (6, 3), (5, 7), (3, 8), (6, 8), (11, 12)]),
        (200_000, [(7, 9), (9, 8), (4, 5)]),
        (3, [(1, 2)]),
        (4, [(1, 3)]),
        (5, [(1, 4)]),
        (8, [(1, 4), (2, 6), (3, 8)]),
        (8, [(1, 2), (2, 3), (5, 6), (6, 7)]),
        (4, [(1, 4), (2, 3)]),
        (10, [(1, 10), (2, 9), (3, 8), (4, 7), (5, 6)]),
    ]
    for _ in range(3):
        n = rng.randint(3, 18)
        m = rng.randint(1, min(n + 5, n * (n - 1) // 2))
        tests.append((n, random_edges(rng, n, m)))

    index = 1
    for n, edges in tests:
        write_case(index, n, edges)
        index += 1

    n = 2_000
    edges = [(i, i + 1_000) for i in range(1, 1_001)]
    rng.shuffle(edges)
    write_case(index, n, edges)
    index += 1

    n = LIMIT
    edges = [(i, i + 1) for i in range(1, n)] + [(1, n)]
    rng.shuffle(edges)
    write_case(index, n, edges)
    index += 1

    edges = [(i, i + 1) for i in range(1, n)]
    rng.shuffle(edges)
    write_case(index, n, edges)
    index += 1

    edges = [(i, i + 100_000) for i in range(1, 100_001)]
    rng.shuffle(edges)
    write_case(index, n, edges)
    index += 1

    write_case(index, n, [(1, n)])
    index += 1

    edges = [(i, i + 1) for i in range(1, n, 2)]
    rng.shuffle(edges)
    write_case(index, n, edges)
    index += 1

    assert index == 19
    print("CF1253D generated 18 inputs")


if __name__ == "__main__":
    main()
