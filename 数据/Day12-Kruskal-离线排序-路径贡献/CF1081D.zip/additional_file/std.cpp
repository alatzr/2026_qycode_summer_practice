#include<bits/stdc++.h>
using namespace std;

const int N = 3e5 + 10;

struct Edge
{
	int u, v, w;
} edges[N];

int fa[N], sz[N], cntSpec[N]; // cntSpec 只在根上有效：块内特殊点个数
int n, m, k;

int find(int x)
{
	if (fa[x] == x) return x;
	return fa[x] = find(fa[x]); // 路径压缩
}

void merge(int x, int y)
{
	x = find(x), y = find(y);
	if (x == y) return;
	if (sz[x] < sz[y]) swap(x, y); // 按大小合并：小块挂到大块
	fa[y] = x;
	sz[x] += sz[y];
	cntSpec[x] += cntSpec[y]; // 特殊点计数一起并
}

bool cmpEdge(const Edge &e1, const Edge &e2)
{
	return e1.w < e2.w;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	cin >> n >> m >> k;
	for (int i = 1; i <= n; i++)
		fa[i] = i, sz[i] = 1, cntSpec[i] = 0;
	for (int i = 1; i <= k; i++)
	{
		int spec;
		cin >> spec;
		cntSpec[spec] = 1;
	}
	for (int i = 1; i <= m; i++)
		cin >> edges[i].u >> edges[i].v >> edges[i].w;

	sort(edges + 1, edges + 1 + m, cmpEdge);

	int ans = 0;
	for (int i = 1; i <= m; i++)
	{
		int ru = find(edges[i].u), rv = find(edges[i].v);
		if (ru == rv) continue;
		merge(ru, rv);
		if (cntSpec[find(ru)] == k) // 全部特殊点第一次进同一块
		{
			ans = edges[i].w;
			break;
		}
	}

	for (int i = 1; i <= k; i++)
		cout << ans << (i == k ? '\n' : ' ');
	return 0;
}
