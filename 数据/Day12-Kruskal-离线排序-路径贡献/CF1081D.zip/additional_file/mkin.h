#!/usr/bin/env python3
"""Deterministic test generator for CF1081D Maximum Distance."""

import random
from collections import deque
from pathlib import Path


N_LIMIT = 100_000
M_LIMIT = 100_000
ROOT = Path(__file__).resolve().parent
OUT = ROOT / "inputs"


def write_case(index, n, specials, edges):
    assert 2 <= len(specials) <= n <= N_LIMIT
    assert len(set(specials)) == len(specials)
    assert n - 1 <= len(edges) <= M_LIMIT
    graph = [[] for _ in range(n + 1)]
    for u, v, w in edges:
        assert 1 <= u <= n and 1 <= v <= n and 1 <= w <= 10**9
        graph[u].append(v)
        graph[v].append(u)
    vis = [False] * (n + 1)
    q = deque([1])
    vis[1] = True
    while q:
        u = q.popleft()
        for v in graph[u]:
            if not vis[v]:
                vis[v] = True
                q.append(v)
    assert all(vis[1:])
    lines = [f"{n} {len(edges)} {len(specials)}", " ".join(map(str, specials))]
    lines.extend(f"{u} {v} {w}" for u, v, w in edges)
    (OUT / f"{index}.in").write_text("\n".join(lines) + "\n", encoding="ascii")


def random_connected(rng, n, m, wmax):
    edges = [(rng.randint(1, v - 1), v, rng.randint(1, wmax)) for v in range(2, n + 1)]
    while len(edges) < m:
        edges.append((rng.randint(1, n), rng.randint(1, n), rng.randint(1, wmax)))
    rng.shuffle(edges)
    return edges


def main():
    rng = random.Random(10_812_026)
    OUT.mkdir(parents=True, exist_ok=True)
    for old in OUT.glob("*.in"):
        old.unlink()

    tests = [
        (2, [2, 1], [(1, 2, 3), (1, 2, 2), (2, 2, 1)]),
        (4, [1, 2, 3], [(1, 2, 5), (4, 2, 1), (2, 3, 2), (1, 4, 4), (1, 3, 3)]),
        (2, [1, 2], [(1, 2, 10**9)]),
        (3, [1, 3], [(1, 2, 5), (2, 3, 5), (1, 3, 9), (2, 2, 1)]),
        (6, [1, 2, 3, 4, 5, 6], [(i, i + 1, i) for i in range(1, 6)]),
        (8, [2, 4, 6, 8], [(1, i, 7) for i in range(2, 9)]),
        (6, [1, 6], [(1, 2, 8), (2, 3, 8), (3, 4, 8), (4, 5, 8), (5, 6, 8), (2, 5, 4)]),
        (8, [1, 3, 6, 8], [(1, 2, 2), (2, 3, 3), (3, 4, 4), (4, 5, 100), (5, 6, 1), (6, 7, 2), (7, 8, 3)]),
    ]
    for _ in range(4):
        n = rng.randint(4, 25)
        m = rng.randint(n - 1, min(45, N_LIMIT))
        k = rng.randint(2, n)
        tests.append((n, rng.sample(range(1, n + 1), k), random_connected(rng, n, m, 1000)))

    index = 1
    for n, specials, edges in tests:
        write_case(index, n, specials, edges)
        index += 1

    n = 2_000
    write_case(index, n, rng.sample(range(1, n + 1), 1_000), random_connected(rng, n, 3_000, 10**9))
    index += 1

    n = N_LIMIT
    edges = [(i, i + 1, (i * 1_000_003) % 10**9 + 1) for i in range(1, n)]
    rng.shuffle(edges)
    write_case(index, n, [1, n], edges)
    index += 1

    edges = [(1, i, 123_456_789) for i in range(2, n + 1)]
    rng.shuffle(edges)
    write_case(index, n, list(range(1, n + 1)), edges)
    index += 1

    edges = random_connected(rng, n, M_LIMIT, 10**9)
    write_case(index, n, list(range(1, n + 1, 2)), edges)
    index += 1

    edges = [(i, i + 1, 10**9) for i in range(1, n)]
    edges.append((1, 2, 1))
    rng.shuffle(edges)
    write_case(index, n, [1, n], edges)
    index += 1

    assert index == 18
    print("CF1081D generated 17 inputs")


if __name__ == "__main__":
    main()
