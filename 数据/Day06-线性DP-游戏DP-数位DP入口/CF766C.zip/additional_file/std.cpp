#include<bits/stdc++.h>
using namespace std;

const int MOD = 1e9 + 7;
const int INF = 1e9;
const int N = 1010;

long long ways[N];   // ways[i]：前 i 个字符的分割方案数
int minCnt[N];       // minCnt[i]：前 i 个字符最少分成几段
int limitOf[26];     // 每个字母允许所在段的最大长度

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    string s;
    cin >> n >> s;
    s = ' ' + s;                      // 转成 1 下标
    for(int i = 0; i < 26; i++) cin >> limitOf[i];

    ways[0] = 1;
    minCnt[0] = 0;
    int bestLen = 0;

    for(int i = 1; i <= n; i++){
        ways[i] = 0;
        minCnt[i] = INF;
        int lim = INF;

        for(int j = i; j >= 1; j--){              // 枚举最后一段 [j, i]
            lim = min(lim, limitOf[s[j] - 'a']);  // 段内每个字母都限制段长
            int len = i - j + 1;
            if(len > lim) break;                  // 再往左扩只会更长，直接停

            ways[i] = (ways[i] + ways[j - 1]) % MOD;
            minCnt[i] = min(minCnt[i], minCnt[j - 1] + 1);
            bestLen = max(bestLen, len);          // 单字符段永远合法，该段必能拼进某个完整方案
        }
    }

    cout << ways[n] << '\n' << bestLen << '\n' << minCnt[n] << '\n';
    return 0;
}
