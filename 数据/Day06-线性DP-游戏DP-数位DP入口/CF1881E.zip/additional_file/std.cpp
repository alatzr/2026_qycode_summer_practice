#include<bits/stdc++.h>
using namespace std;

const int N = 2e5 + 10;
int n, val[N], f[N];

void solve(){
    cin >> n;
    for(int i = 1; i <= n; i++) cin >> val[i];

    // f[i]：把 i..n 整理成合法块序列的最少删除数，从后往前推
    f[n + 1] = 0;
    for(int i = n; i >= 1; i--){
        f[i] = f[i + 1] + 1;                     // 决策一：删掉当前元素
        if(i + val[i] <= n)                      // 决策二：保留以 val[i] 为块长的整块
            f[i] = min(f[i], f[i + val[i] + 1]);
    }
    cout << f[1] << '\n';
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int T;
    cin >> T;
    while(T--) solve();
    return 0;
}
