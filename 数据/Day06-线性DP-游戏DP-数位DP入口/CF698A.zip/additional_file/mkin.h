#!/usr/bin/env python3
# CF698A Vacations 生成器（确定性 seed）
# 约束：1<=n<=100，a_i in {0,1,2,3}。单测格式：n 换行 a1..an。
import os, random

OUT = os.path.join(os.path.dirname(__file__), "inputs")
os.makedirs(OUT, exist_ok=True)

# 官方样例（逐字符复制）
samples = [
    "4\n1 3 2 0\n",
    "7\n1 3 3 2 1 2 3\n",
    "2\n2 2\n",
]


def build(arr):
    return f"{len(arr)}\n" + " ".join(map(str, arr)) + "\n"


def main():
    rng = random.Random(6980)
    files = list(samples)

    # --- 边界组 ---
    files.append(build([0]))            # n=1 全 0，只能休息
    files.append(build([3]))            # n=1 可比赛/健身，0 休息
    files.append(build([0, 0]))         # 全 0，全休息
    files.append(build([3, 3]))         # 都能做，需交替，0 休息
    files.append(build([1, 1]))         # 连续比赛日 -> 必有一天休息
    files.append(build([2, 2]))         # 连续健身日 -> 必有一天休息
    files.append(build([0] * 100))      # 顶格全 0

    # --- 小随机组（供 bf 对拍） ---
    for _ in range(5):
        n = rng.randint(1, 12)
        files.append(build([rng.randint(0, 3) for _ in range(n)]))

    # --- 结构化组（针对贪心/连续限制） ---
    files.append(build([3] * 20))                       # 全 3 交替，0 休息
    files.append(build([1, 2] * 15))                    # 严格交替
    files.append(build([1, 1, 2, 2] * 10))              # 成对逼出休息
    files.append(build([3, 1, 3, 1, 3, 2, 3, 2] * 5))   # 混合结构

    # --- 满量程组 ---
    files.append(build([rng.randint(0, 3) for _ in range(100)]))  # 顶格随机
    files.append(build([3] * 100))                                # 顶格全 3
    files.append(build(([1, 1] * 50)))                            # 顶格全比赛日

    for idx, content in enumerate(files, 1):
        with open(os.path.join(OUT, f"{idx}.in"), "w", newline="\n") as fh:
            fh.write(content)
    print(f"CF698A 生成 {len(files)} 个输入")


if __name__ == "__main__":
    main()
