#include<bits/stdc++.h>
using namespace std;

const int INF = 1e9;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;

    vector<int> a(n + 1);
    for(int i = 1; i <= n; i++) cin >> a[i];

    // dp[i][0/1/2]：第 i 天 休息/比赛/健身 时前 i 天最少休息数
    vector<array<int,3>> dp(n + 1, {INF, INF, INF});
    dp[0][0] = dp[0][1] = dp[0][2] = 0;

    for(int i = 1; i <= n; i++){
        dp[i][0] = min({dp[i-1][0], dp[i-1][1], dp[i-1][2]}) + 1; // 休息永远可行
        if(a[i] == 1 || a[i] == 3)
            dp[i][1] = min(dp[i-1][0], dp[i-1][2]); // 今天比赛，昨天不能比赛
        if(a[i] == 2 || a[i] == 3)
            dp[i][2] = min(dp[i-1][0], dp[i-1][1]); // 今天健身，昨天不能健身
    }

    cout << min({dp[n][0], dp[n][1], dp[n][2]}) << '\n';
    return 0;
}
