#include<bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int len, sum;
    cin >> len >> sum;

    // 无解：数位和超过 9*len；或和为 0 但位数超过 1（首位不能为 0）
    if(sum > 9 * len || (sum == 0 && len > 1)){
        cout << "-1 -1\n";
        return 0;
    }
    if(sum == 0){                // 此时必有 len==1，唯一答案是 0
        cout << "0 0\n";
        return 0;
    }

    // 最大数：从最高位开始尽量放 9
    string mx(len, '0');
    int rest = sum;
    for(int i = 0; i < len; i++){
        int digit = min(9, rest);
        mx[i] = char('0' + digit);
        rest -= digit;
    }

    // 最小数：首位先放 1 保证无前导零，剩余的和从最低位往回尽量放 9
    string mn(len, '0');
    mn[0] = '1';
    rest = sum - 1;
    for(int i = len - 1; i >= 0 && rest > 0; i--){
        int add = min(9 - (mn[i] - '0'), rest);
        mn[i] = char(mn[i] + add);
        rest -= add;
    }

    cout << mn << ' ' << mx << '\n';
    return 0;
}
