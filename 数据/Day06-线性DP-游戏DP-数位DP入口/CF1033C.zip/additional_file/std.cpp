#include<bits/stdc++.h>
using namespace std;

const int N = 1e5 + 10;
int n, perm[N], posOf[N];
bool win[N];   // win[i]：轮到走的人面对位置 i 是否必胜

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> n;
    for(int i = 1; i <= n; i++){
        cin >> perm[i];
        posOf[perm[i]] = i;
    }

    // 只能跳向数值更大的位置，按数值从大到小处理，后继状态一定已算好
    for(int val = n; val >= 1; val--){
        int cur = posOf[val];
        win[cur] = false;
        for(int nxt = cur + val; nxt <= n && !win[cur]; nxt += val)
            if(perm[nxt] > val && !win[nxt]) win[cur] = true;  // 存在必败后继则必胜
        for(int nxt = cur - val; nxt >= 1 && !win[cur]; nxt -= val)
            if(perm[nxt] > val && !win[nxt]) win[cur] = true;
    }

    string result(n, 'B');
    for(int i = 1; i <= n; i++)
        if(win[i]) result[i - 1] = 'A';
    cout << result << '\n';
    return 0;
}
