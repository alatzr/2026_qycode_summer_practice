#include<bits/stdc++.h>
using namespace std;

int dig[20];                 // 上界的每一位，低位存在下标 0
long long memo[20][4];       // memo[pos][cnt]：不贴上界时的方案数，与具体上界无关

// pos：当前填第几位（从高往低，填完为 -1）
// cnt：已经用掉的非零数字个数
// tight：前面每一位是否都贴着上界
long long dfs(int pos, int cnt, bool tight){
    if(cnt > 3) return 0;                  // 非零数字超过 3 个，直接剪掉
    if(pos < 0) return 1;                  // 所有位填完，得到一个合法数
    if(!tight && memo[pos][cnt] != -1) return memo[pos][cnt];

    int up = tight ? dig[pos] : 9;         // 本位能填的最大数字
    long long total = 0;
    for(int d = 0; d <= up; d++)
        total += dfs(pos - 1, cnt + (d != 0), tight && d == up);

    if(!tight) memo[pos][cnt] = total;     // 只有不贴上界的状态才能复用
    return total;
}

// 统计 [0, x] 中非零数字不超过 3 个的数的个数
long long countClassy(long long x){
    if(x < 0) return 0;
    int len = 0;
    if(x == 0) dig[len++] = 0;
    while(x > 0){
        dig[len++] = x % 10;
        x /= 10;
    }
    return dfs(len - 1, 0, true);
}

void solve(){
    long long lo, hi;
    cin >> lo >> hi;
    cout << countClassy(hi) - countClassy(lo - 1) << '\n';
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    memset(memo, -1, sizeof memo);         // memo 不依赖上界，整个程序只需清一次
    int T;
    cin >> T;
    while(T--) solve();
    return 0;
}
