#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int n;
ll c, d;
vector<ll> pref;                        // 降序前缀和
// 冷却为 k 时 d 天最多金币：周期 k+1 天，用前 min(k+1,n) 大的任务轮转
ll coins(ll k){
    ll cyc = k + 1;
    ll usable = min(cyc, (ll)n);
    ll full = d / cyc;
    ll rem = d % cyc;
    return full * pref[usable] + pref[min(rem, (ll)n)];
}
void solve(){
    scanf("%d %lld %lld", &n, &c, &d);
    vector<ll> a(n);
    for(auto &x : a) scanf("%lld", &x);
    sort(a.rbegin(), a.rend());
    pref.assign(n + 1, 0);
    for(int i = 0; i < n; i++) pref[i + 1] = pref[i] + a[i];
    // 只用不同任务（永不重复）就够 c：k 可任意大
    if(pref[min((ll)n, d)] >= c){ printf("Infinity\n"); return; }
    // 连 k=0（每天打最大任务）都不够：无解
    if(coins(0) < c){ printf("Impossible\n"); return; }
    ll lo = 0, hi = d, ans = 0;         // coins(k) 关于 k 单调不增，二分最大可行 k
    while(lo <= hi){
        ll mid = (lo + hi) / 2;
        if(coins(mid) >= c){ ans = mid; lo = mid + 1; }
        else hi = mid - 1;
    }
    printf("%lld\n", ans);
}
int main(){
    int t;
    scanf("%d", &t);
    while(t--) solve();
    return 0;
}
