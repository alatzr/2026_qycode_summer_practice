#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T;
    cin >> T;
    while(T--){
        int n;
        cin >> n;
        ll mn = (ll)4e18, mx = 0;
        ll cmn = 0, cmx = 0, clen = 0;
        ll mlen = -1;
        for(int i = 0; i < n; i++){
            ll l, r, c;
            cin >> l >> r >> c;
            if(l < mn){
                mn = l;
                cmn = c;
            }else if(l == mn){
                cmn = min(cmn, c);
            }
            if(r > mx){
                mx = r;
                cmx = c;
            }else if(r == mx){
                cmx = min(cmx, c);
            }
            ll len = r - l;
            if(len > mlen){
                mlen = len;
                clen = c;
            }else if(len == mlen){
                clen = min(clen, c);
            }
            ll ans = cmn + cmx;
            if(l <= mn && r >= mx) ans = min(ans, c);
            if(mlen >= mx - mn) ans = min(ans, clen);
            cout << ans << '\n';
        }
    }
    return 0;
}
