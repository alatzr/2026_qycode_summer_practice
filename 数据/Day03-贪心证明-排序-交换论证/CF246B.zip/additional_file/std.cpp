#include<bits/stdc++.h>
using namespace std;
int main(){
    int n;
    scanf("%d", &n);
    long long sum = 0;
    for(int i = 0; i < n; i++){
        long long x;
        scanf("%lld", &x);
        sum += x;
    }
    // 操作保持总和不变；能全相等当且仅当 sum 能被 n 整除
    printf("%d\n", sum % n == 0 ? n : n - 1);
    return 0;
}
