#include<bits/stdc++.h>
using namespace std;
int main(){
    long long n, a, b, k;
    scanf("%lld %lld %lld %lld", &n, &a, &b, &k);
    vector<long long> need;             // 每只怪需要的跳过次数
    for(int i = 0; i < n; i++){
        long long h;
        scanf("%lld", &h);
        long long rem = ((h - 1) % (a + b)) + 1;    // 最后一轮剩余血量
        long long skip = (rem + a - 1) / a - 1;     // 需要跳过对手的次数
        need.push_back(skip);
    }
    sort(need.begin(), need.end());
    int cnt = 0;
    for(long long s : need){
        if(k >= s){ k -= s; cnt++; }    // 跳过次数够就抢这只怪的最后一击
        else break;
    }
    printf("%d\n", cnt);
    return 0;
}
