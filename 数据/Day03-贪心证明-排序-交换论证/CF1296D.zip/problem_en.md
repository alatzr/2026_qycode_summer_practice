# CF1296D · Fight with Monsters

- 难度：1500
- 标签：greedy、sortings
- 链接：https://codeforces.com/problemset/problem/1296/D
- 时间限制：1 second　内存限制：256 megabytes
- 出现位置：Day03-贪心证明-排序-交换论证

## 英文原题面

### Statement

There are $n$ monsters standing in a row numbered from $1$ to $n$. The $i$-th monster has $h_i$ health points (hp). You have your attack power equal to $a$ hp and your opponent has his attack power equal to $b$ hp.
You and your opponent are fighting these monsters. Firstly, you and your opponent go to the first monster and fight it till his death, then you and your opponent go the second monster and fight it till his death, and so on. A monster is considered dead if its hp is less than or equal to $0$.
The fight with a monster happens in turns. 
 -  You hit the monster by $a$ hp. If it is dead after your hit, you gain one point and you both proceed to the next monster. 
-  Your opponent hits the monster by $b$ hp. If it is dead after his hit, nobody gains a point and you both proceed to the next monster. 

You have some secret technique to force your opponent to skip his turn. You can use this technique at most $k$ times in total (for example, if there are two monsters and $k=4$, then you can use the technique $2$ times on the first monster and $1$ time on the second monster, but not $2$ times on the first monster and $3$ times on the second monster).
Your task is to determine the maximum number of points you can gain if you use the secret technique optimally.

### Input

The first line of the input contains four integers $n, a, b$ and $k$ ($1 \le n \le 2 \cdot 10^5, 1 \le a, b, k \le 10^9$) — the number of monsters, your attack power, the opponent's attack power and the number of times you can use the secret technique.
The second line of the input contains $n$ integers $h_1, h_2, \dots, h_n$ ($1 \le h_i \le 10^9$), where $h_i$ is the health points of the $i$-th monster.

### Output

Print one integer — the maximum number of points you can gain if you use the secret technique optimally.

## 样例

### 样例 1

输入：

```text
6 2 3 3
7 10 50 12 1 8
```

输出：

```text
5
```

### 样例 2

输入：

```text
1 1 100 99
100
```

输出：

```text
1
```

### 样例 3

输入：

```text
7 4 2 1
1 3 5 4 2 7 6
```

输出：

```text
6
```