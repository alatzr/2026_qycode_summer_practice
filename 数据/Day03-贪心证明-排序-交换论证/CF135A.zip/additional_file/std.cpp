#include<bits/stdc++.h>
using namespace std;
int main(){
    int n;
    scanf("%d", &n);
    vector<int> a(n);
    int mxPos = 0;
    for(int i = 0; i < n; i++){
        scanf("%d", &a[i]);
        if(a[i] > a[mxPos]) mxPos = i;
    }
    a[mxPos] = (a[mxPos] == 1 ? 2 : 1);  // 最大换成 1；若已是 1 则换成 2
    sort(a.begin(), a.end());
    for(int i = 0; i < n; i++) printf("%d%c", a[i], i + 1 == n ? '\n' : ' ');
    return 0;
}
