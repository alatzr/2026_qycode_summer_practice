#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
void solve(){
    int n;
    scanf("%d", &n);
    vector<ll> a(n + 1);
    for(int i = 1; i <= n; i++) scanf("%lld", &a[i]);
    // 存在真子段和 >= 全段和，等价于去掉某非空前缀或后缀后剩余 >= 全段
    // 即某个非空前缀和 <= 0，或某个非空后缀和 <= 0，则 Yasser 不开心
    ll pre = 0;
    bool bad = false;
    for(int i = 1; i <= n - 1; i++){ pre += a[i]; if(pre <= 0) bad = true; }  // 去掉的前缀
    ll suf = 0;
    for(int i = n; i >= 2; i--){ suf += a[i]; if(suf <= 0) bad = true; }      // 去掉的后缀
    printf("%s\n", bad ? "NO" : "YES");
}
int main(){
    int t;
    scanf("%d", &t);
    while(t--) solve();
    return 0;
}
