#include<bits/stdc++.h>
using namespace std;
int main(){
    int n;
    scanf("%d", &n);
    vector<int> weight(n);
    for(int i = 0; i < n; i++) scanf("%d", &weight[i]);
    sort(weight.begin(), weight.end());
    int last = 0, cnt = 0;              // last：上一个已占用的最终重量
    for(int i = 0; i < n; i++){
        int cand = max(weight[i] - 1, last + 1);   // 尽量取最小的可用重量
        if(cand <= weight[i] + 1){                 // 落在 [w-1,w+1] 内才合法
            last = cand;
            cnt++;
        }
    }
    printf("%d\n", cnt);
    return 0;
}
