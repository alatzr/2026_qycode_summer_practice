#include<bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, k;
    cin >> n >> k;

    vector<pair<long long, long long>> songs(n); // {美观度, 时长}
    for(int i = 0; i < n; i++){
        long long len, beauty;
        cin >> len >> beauty;
        songs[i] = {beauty, len};
    }
    // 按美观度从大到小排：扫到第 i 首时，它的美观度就是当前集合的最小值
    sort(songs.begin(), songs.end(), greater<pair<long long, long long>>());

    // 已选歌曲时长的小根堆：超员时反悔，扔掉最短的
    priority_queue<long long, vector<long long>, greater<long long>> lenHeap;
    long long lenSum = 0, ans = 0;

    for(auto &[beauty, len] : songs){
        lenHeap.push(len); // 先把当前歌选进来
        lenSum += len;
        if((int)lenHeap.size() > k){ // 超过 k 首：删时长最短的一首
            lenSum -= lenHeap.top();
            lenHeap.pop();
        }
        ans = max(ans, lenSum * beauty);
    }

    cout << ans << '\n';
    return 0;
}
