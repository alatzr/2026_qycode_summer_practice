#include<bits/stdc++.h>
using namespace std;

void solve(){
    int n;
    cin >> n;
    vector<long long> tokens(n + 1);
    vector<int> order(n + 1);
    for(int i = 1; i <= n; i++){
        cin >> tokens[i];
        order[i] = i;
    }
    // 按代币数从小到大排序，order 里存原编号
    sort(order.begin() + 1, order.end(), [&](int lhs, int rhs){
        return tokens[lhs] < tokens[rhs];
    });

    vector<long long> prefix(n + 1, 0); // 排序后前 i 名的代币总和
    for(int i = 1; i <= n; i++) prefix[i] = prefix[i - 1] + tokens[order[i]];

    // pos：排序后最靠左的能夺冠位置
    int pos = n;
    for(int i = n - 1; i >= 1; i--){
        if(prefix[i] >= tokens[order[i + 1]]) pos = i; // 吃下前 i 名后能打赢第 i+1 名
        else break; // 断档：再往左都跨不过这里
    }

    vector<int> winners(order.begin() + pos, order.begin() + n + 1);
    sort(winners.begin(), winners.end()); // 按原编号升序输出
    cout << winners.size() << '\n';
    for(int i = 0; i < (int)winners.size(); i++)
        cout << winners[i] << (i + 1 == (int)winners.size() ? '\n' : ' ');
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while(t--) solve();
    return 0;
}
