#include<bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, k1, k2;
    cin >> n >> k1 >> k2;

    vector<long long> arr1(n), arr2(n);
    for(auto &x : arr1) cin >> x;
    for(auto &x : arr2) cin >> x;

    // 大根堆：堆顶是当前最大的差值
    priority_queue<long long> diffHeap;
    for(int i = 0; i < n; i++) diffHeap.push(llabs(arr1[i] - arr2[i]));

    int ops = k1 + k2; // 两个数组上的操作对差值完全等价，合并使用
    while(ops--){
        long long top = diffHeap.top();
        diffHeap.pop();
        if(top > 0) top--; // 把最大差值削 1
        else top = 1;      // 差值全为 0 仍必须操作，只能造出一个 1
        diffHeap.push(top);
    }

    long long error = 0;
    while(!diffHeap.empty()){
        error += diffHeap.top() * diffHeap.top(); // 平方和会爆 int，用 long long
        diffHeap.pop();
    }
    cout << error << '\n';
    return 0;
}
