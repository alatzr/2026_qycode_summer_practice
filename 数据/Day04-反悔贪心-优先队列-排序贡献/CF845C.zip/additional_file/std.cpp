#include<bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;
    vector<pair<int, int>> shows(n); // {开始时刻, 结束时刻}
    for(auto &show : shows) cin >> show.first >> show.second;
    sort(shows.begin(), shows.end()); // 按开始时刻升序

    // 两台电视各自的结束时刻，始终保持 endEarly <= endLate
    long long endEarly = -1, endLate = -1;
    bool ok = true;
    for(auto &[start, finish] : shows){
        if(start > endEarly){ // 只需和先空出来的电视比较；端点相同不能接
            endEarly = finish;
            if(endEarly > endLate) swap(endEarly, endLate);
        }else{ // 两台电视都还没结束，第三个节目冲突
            ok = false;
            break;
        }
    }
    cout << (ok ? "YES" : "NO") << '\n';
    return 0;
}
