#include<bits/stdc++.h>
using namespace std;

vector<int> zfunc(const string& s) {
    int n = s.size();
    vector<int> z(n);
    int l = 0, r = 0;
    for (int i = 1; i < n; i++) {
        if (i <= r) z[i] = min(r - i + 1, z[i - l]);
        while (i + z[i] < n && s[z[i]] == s[i + z[i]]) z[i]++;
        if (i + z[i] - 1 > r) l = i, r = i + z[i] - 1;
    }
    return z;
}

int can(const vector<int>& z, int len) {
    int n = z.size(), cnt = 1;
    for (int i = len; i < n; ) {
        if (z[i] >= len) {
            cnt++;
            i += len;
        } else i++;
    }
    return cnt;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T;
    cin >> T;
    while (T--) {
        int n, l, r;
        string s;
        cin >> n >> l >> r >> s;
        int k = l;
        auto z = zfunc(s);
        int lo = 0, hi = n + 1;
        while (hi - lo > 1) {
            int mid = (lo + hi) / 2;
            if (can(z, mid) >= k) lo = mid;
            else hi = mid;
        }
        cout << lo << '\n';
    }
    return 0;
}
