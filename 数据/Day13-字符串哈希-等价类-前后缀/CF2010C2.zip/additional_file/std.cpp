#include<bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;

const ull BASE = 131;
const int N = 4e5 + 10;

int n;
string t;
ull preHash[N], pw[N];

ull get(int l, int r){   // 子串 t[l..r] 的哈希值，1 下标
    return preHash[r] - preHash[l - 1] * pw[r - l + 1];
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cin >> t;
    n = t.size();
    pw[0] = 1;
    for(int i = 1; i <= n; i++){
        pw[i] = pw[i - 1] * BASE;
        preHash[i] = preHash[i - 1] * BASE + t[i - 1];
    }
    // 原串长 L：重叠 ov = 2L - n 必须满足 1 <= ov <= L-1，即 n/2 < L <= n-1
    for(int L = n - 1; L * 2 > n; L--)
        if(get(1, L) == get(n - L + 1, n)){
            cout << "YES\n" << t.substr(0, L) << '\n';
            return 0;
        }
    cout << "NO\n";
    return 0;
}
