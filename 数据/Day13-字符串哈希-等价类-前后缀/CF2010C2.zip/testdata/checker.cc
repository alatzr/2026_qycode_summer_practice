#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;
// 2010C2 多解校验：可行 <=> 存在 L, n/2 < L <= n-1 且 t 的长 L 前缀 == 长 L 后缀。
// YES s 合法 <=> |s|=L 在范围内且 t.substr(0,L)==s==t.substr(n-L,L)。NO 合法 <=> 无此 L。
int main(int argc, char* argv[]){
    registerTestlibCmd(argc, argv);
    string t = inf.readWord();
    int n = (int)t.size();
    bool feasible = false;
    for(int L = n - 1; 2 * L > n; L--){
        if(t.compare(0, L, t, n - L, L) == 0){ feasible = true; break; }
    }
    string verdict = ouf.readWord();
    for(auto &c : verdict) c = toupper(c);
    if(verdict == "NO"){
        if(feasible) quitf(_wa, "answered NO but a valid split exists");
        quitf(_ok, "correctly NO");
    }
    if(verdict != "YES") quitf(_wa, "expected YES or NO, got %s", verdict.c_str());
    if(!feasible) quitf(_wa, "answered YES but no valid split exists");
    string s = ouf.readWord();
    int L = (int)s.size();
    if(!(2 * L > n && L <= n - 1)) quitf(_wa, "length %d out of range (need n/2<L<=n-1, n=%d)", L, n);
    if(t.compare(0, L, s) != 0) quitf(_wa, "s is not the length-%d prefix of t", L);
    if(t.compare(n - L, L, s) != 0) quitf(_wa, "s is not the length-%d suffix of t", L);
    quitf(_ok, "valid s length %d", L);
}
