#include<bits/stdc++.h>
using namespace std;

void solve(){
    int n, m;
    string s;
    cin >> n >> m >> s;
    s = "#" + s;   // 改成 1 下标
    vector<int> nxt1(n + 2), pre0(n + 2);
    nxt1[n + 1] = n + 1;                    // 哨兵：右边没有 1
    for(int i = n; i >= 1; i--)
        nxt1[i] = (s[i] == '1') ? i : nxt1[i + 1];
    pre0[0] = 0;                            // 哨兵：左边没有 0
    for(int i = 1; i <= n; i++)
        pre0[i] = (s[i] == '0') ? i : pre0[i - 1];

    set<pair<int, int>> keys;               // 等价键去重
    while(m--){
        int l, r;
        cin >> l >> r;
        int firstOne = nxt1[l];             // [l,r] 内第一个 1
        int lastZero = pre0[r];             // [l,r] 内最后一个 0
        if(firstOne > lastZero) keys.insert({0, 0});        // 排序不改变串
        else keys.insert({firstOne, lastZero});             // 真正变化的核心区间
    }
    cout << keys.size() << '\n';
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T;
    cin >> T;
    while(T--) solve();
    return 0;
}
