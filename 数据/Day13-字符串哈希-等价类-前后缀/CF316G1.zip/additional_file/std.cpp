#include<bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;

const ull BASE = 131;
const int N = 210;

ull pw[N];

// 求一个串的前缀哈希数组（1 下标公式）
vector<ull> buildHash(const string &raw){
    int len = raw.size();
    vector<ull> pre(len + 1, 0);
    for(int i = 1; i <= len; i++) pre[i] = pre[i - 1] * BASE + raw[i - 1];
    return pre;
}

ull getHash(const vector<ull> &pre, int l, int r){
    return pre[r] - pre[l - 1] * pw[r - l + 1];
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string s;
    int ruleCnt;
    cin >> s >> ruleCnt;
    int n = s.size();
    pw[0] = 1;
    for(int i = 1; i < N; i++) pw[i] = pw[i - 1] * BASE;

    vector<string> ruleStr(ruleCnt);
    vector<int> needLow(ruleCnt), needHigh(ruleCnt);
    // occCnt[k][len]：规则串 k 中每个长度为 len 的子串哈希 -> 出现次数
    vector<vector<map<ull, int>>> occCnt(ruleCnt);
    for(int k = 0; k < ruleCnt; k++){
        cin >> ruleStr[k] >> needLow[k] >> needHigh[k];
        int plen = ruleStr[k].size();
        vector<ull> preP = buildHash(ruleStr[k]);
        occCnt[k].assign(plen + 1, map<ull, int>());
        for(int len = 1; len <= plen; len++)
            for(int st = 1; st + len - 1 <= plen; st++)
                occCnt[k][len][getHash(preP, st, st + len - 1)]++;
    }

    vector<ull> preS = buildHash(s);
    set<pair<int, ull>> seen;   // (长度, 哈希) 去重：相同子串只判一次
    long long good = 0;
    for(int len = 1; len <= n; len++)
        for(int st = 1; st + len - 1 <= n; st++){
            ull hv = getHash(preS, st, st + len - 1);
            if(!seen.insert({len, hv}).second) continue;
            bool ok = true;
            for(int k = 0; k < ruleCnt && ok; k++){
                int cnt = 0;   // 该子串在规则串 k 中的出现次数（不出现记 0）
                if(len <= (int)ruleStr[k].size()){
                    auto it = occCnt[k][len].find(hv);
                    if(it != occCnt[k][len].end()) cnt = it->second;
                }
                if(cnt < needLow[k] || cnt > needHigh[k]) ok = false;
            }
            if(ok) good++;
        }
    cout << good << '\n';
    return 0;
}
