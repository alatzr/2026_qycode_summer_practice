#include<bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;

const ull BASE = 131;
const int N = 1e6 + 10;

int n;
string s;
ull preHash[N], pw[N];

ull get(int l, int r){   // 子串 s[l..r] 的哈希值，1 下标
    return preHash[r] - preHash[l - 1] * pw[r - l + 1];
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cin >> s;
    if(!s.empty() && s.back()=='\r') s.pop_back();
    n = s.size();
    pw[0] = 1;
    for(int i = 1; i <= n; i++){
        pw[i] = pw[i - 1] * BASE;
        preHash[i] = preHash[i - 1] * BASE + s[i - 1];
    }
    // 第一步：最长 border b1（既是前缀又是后缀，长度 < n）
    int b1 = 0;
    for(int len = n - 1; len >= 1; len--)
        if(get(1, len) == get(n - len + 1, n)){ b1 = len; break; }
    if(b1 == 0){ cout << "Just a legend\n"; return 0; }
    // 第二步：prefix(b1) 是否在中间出现（起点 2..，终点不到 n）
    bool midHit = false;
    for(int st = 2; st + b1 - 1 <= n - 1; st++)
        if(get(st, st + b1 - 1) == get(1, b1)){ midHit = true; break; }
    if(midHit){ cout << s.substr(0, b1) << '\n'; return 0; }
    // 第三步：退到次长 border b2 = prefix(b1) 的最长 border，它必然在中间出现
    int b2 = 0;
    for(int len = b1 - 1; len >= 1; len--)
        if(get(1, len) == get(b1 - len + 1, b1)){ b2 = len; break; }
    if(b2 == 0) cout << "Just a legend\n";
    else cout << s.substr(0, b2) << '\n';
    return 0;
}
