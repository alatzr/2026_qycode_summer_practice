#include<bits/stdc++.h>
using namespace std;

// 求等价类的标准形：奇数长度是自己；偶数长度取两半标准形的较小拼接
string norm(const string &str){
    int len = str.size();
    if(len & 1) return str;
    string half1 = norm(str.substr(0, len / 2));
    string half2 = norm(str.substr(len / 2));
    return half1 < half2 ? half1 + half2 : half2 + half1;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string s1, s2;
    cin >> s1 >> s2;
    cout << (norm(s1) == norm(s2) ? "YES" : "NO") << '\n';
    return 0;
}
