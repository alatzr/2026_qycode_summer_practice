#include<bits/stdc++.h>
using namespace std;

void solve(){
    int n;
    string s;
    cin >> n >> s;
    vector<int> preCnt(n), sufCnt(n);
    int maskPre = 0, maskSuf = 0;   // 26 位标记出现过的字母
    for(int i = 0; i < n; i++){
        maskPre |= 1 << (s[i] - 'a');
        preCnt[i] = __builtin_popcount(maskPre);
    }
    for(int i = n - 1; i >= 0; i--){
        maskSuf |= 1 << (s[i] - 'a');
        sufCnt[i] = __builtin_popcount(maskSuf);
    }
    int ans = 0;
    for(int cut = 0; cut + 1 < n; cut++)   // 前段 [0,cut]，后段 [cut+1,n-1]
        ans = max(ans, preCnt[cut] + sufCnt[cut + 1]);
    cout << ans << '\n';
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T;
    cin >> T;
    while(T--) solve();
    return 0;
}
