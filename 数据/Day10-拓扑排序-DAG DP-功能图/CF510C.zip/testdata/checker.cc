#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;
int rnk[256];
bool leq(const string& a, const string& b){
    int n = (int)min(a.size(), b.size());
    for(int i = 0; i < n; i++){ if(a[i] == b[i]) continue; return rnk[(int)a[i]] < rnk[(int)b[i]]; }
    return a.size() <= b.size();
}
int main(int argc, char* argv[]){
    registerTestlibCmd(argc, argv);
    int n = inf.readInt();
    vector<string> names(n);
    for(int i = 0; i < n; i++) names[i] = inf.readWord();
    // 独立判可行性：相邻名字导出字母约束 + 前缀违例 + 环检测
    vector<vector<int>> g(26); vector<int> indeg(26, 0); bool hasE[26][26] = {}; bool impossible = false;
    for(int i = 0; i + 1 < n; i++){
        const string& a = names[i]; const string& b = names[i + 1];
        int L = (int)min(a.size(), b.size()), p = 0;
        while(p < L && a[p] == b[p]) p++;
        if(p == L){ if(a.size() > b.size()) impossible = true; continue; }
        int u = a[p] - 'a', v = b[p] - 'a';
        if(!hasE[u][v]){ hasE[u][v] = true; g[u].push_back(v); indeg[v]++; }
    }
    if(!impossible){
        vector<int> ind = indeg; queue<int> q; int cnt = 0;
        for(int i = 0; i < 26; i++) if(ind[i] == 0) q.push(i);
        while(!q.empty()){ int u = q.front(); q.pop(); cnt++; for(int v : g[u]) if(--ind[v] == 0) q.push(v); }
        if(cnt < 26) impossible = true;
    }
    string tok = ouf.readWord();
    if(tok == "Impossible"){
        if(!impossible) quitf(_wa, "answered Impossible but a valid order exists");
        quitf(_ok, "Impossible");
    }
    if((int)tok.size() != 26) quitf(_wa, "expected 26-letter permutation or 'Impossible', got len %d", (int)tok.size());
    vector<int> seen(26, 0);
    for(char c : tok){ if(c < 'a' || c > 'z') quitf(_wa, "non-letter"); if(seen[c - 'a']++) quitf(_wa, "repeated letter %c", c); }
    for(int i = 0; i < 26; i++) rnk[(int)tok[i]] = i;
    if(impossible) quitf(_wa, "gave alphabet but instance is impossible");
    for(int i = 0; i + 1 < n; i++) if(!leq(names[i], names[i + 1])) quitf(_wa, "names not sorted under given alphabet at index %d", i);
    quitf(_ok, "valid alphabet");
}
