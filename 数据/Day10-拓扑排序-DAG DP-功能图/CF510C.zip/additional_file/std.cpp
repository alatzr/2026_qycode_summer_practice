#include<bits/stdc++.h>
using namespace std;

vector<int> g[26];
int indeg[26];
bool hasEdge[26][26];  // 判重边，避免入度重复累加

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    vector<string> names(n);
    for(auto &name : names) cin >> name;

    for(int i = 0; i + 1 < n; i++){
        const string &pre = names[i], &nxt = names[i + 1];
        int len = (int)min(pre.size(), nxt.size());
        int pos = 0;
        while(pos < len && pre[pos] == nxt[pos]) pos++;
        if(pos == len){
            // 一串是另一串的前缀：长串排在自己前缀之前必然非法
            if(pre.size() > nxt.size()){
                cout << "Impossible\n";
                return 0;
            }
            continue;  // 前缀在前天然合法，产生不了字母约束
        }
        int u = pre[pos] - 'a', v = nxt[pos] - 'a';  // 约束：u 必须排在 v 前面
        if(!hasEdge[u][v]){
            hasEdge[u][v] = true;
            g[u].push_back(v);
            indeg[v]++;
        }
    }

    queue<int> q;
    for(int i = 0; i < 26; i++)
        if(indeg[i] == 0) q.push(i);

    string order;
    while(!q.empty()){
        int u = q.front();
        q.pop();
        order += char('a' + u);
        for(int v : g[u])
            if(--indeg[v] == 0) q.push(v);
    }

    if((int)order.size() < 26) cout << "Impossible\n";  // 约束成环
    else cout << order << '\n';
    return 0;
}
