#include<bits/stdc++.h>
using namespace std;

void solve(){
    int n, k;
    cin >> n >> k;
    vector<long long> buyPrice(n + 1), cost(n + 1, 0);
    vector<bool> freeSupply(n + 1, false);
    vector<vector<int>> product(n + 1);  // product[u]：以 u 为原料的成品列表
    vector<int> indeg(n + 1, 0);         // 拓扑入度 = 配方原料个数
    vector<int> recipeLen(n + 1, 0);     // 配方长度，0 表示只能购买
    vector<long long> mixSum(n + 1, 0);  // 已结算原料的成本累加

    for(int i = 1; i <= n; i++) cin >> buyPrice[i];
    for(int i = 0; i < k; i++){
        int id;
        cin >> id;
        freeSupply[id] = true;
    }
    for(int i = 1; i <= n; i++){
        cin >> recipeLen[i];
        indeg[i] = recipeLen[i];
        for(int j = 0; j < recipeLen[i]; j++){
            int ingredient;
            cin >> ingredient;
            product[ingredient].push_back(i);  // 边：原料 -> 成品
        }
    }

    queue<int> q;
    for(int i = 1; i <= n; i++)
        if(indeg[i] == 0) q.push(i);

    while(!q.empty()){
        int u = q.front();
        q.pop();
        // 弹出时 u 的全部原料都已结算，确定 u 的最小成本
        if(recipeLen[u] == 0) cost[u] = buyPrice[u];
        else cost[u] = min(buyPrice[u], mixSum[u]);
        if(freeSupply[u]) cost[u] = 0;  // 免费药水强制为 0
        for(int v : product[u]){
            mixSum[v] += cost[u];
            if(--indeg[v] == 0) q.push(v);
        }
    }

    for(int i = 1; i <= n; i++) cout << cost[i] << " \n"[i == n];
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T;
    cin >> T;
    while(T--) solve();
    return 0;
}
