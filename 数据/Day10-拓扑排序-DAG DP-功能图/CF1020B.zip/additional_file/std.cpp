#include<bits/stdc++.h>
using namespace std;

const int N = 1010;
int nxt[N];      // nxt[i]：学生 i 指认的下一个学生
int visMark[N];  // visMark[i]：i 最近一次被访问时的起点编号，0 表示没访问过

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    for(int i = 1; i <= n; i++) cin >> nxt[i];
    for(int start = 1; start <= n; start++){
        int cur = start;
        while(visMark[cur] != start){  // 第一个被走到第二次的点就是答案
            visMark[cur] = start;
            cur = nxt[cur];
        }
        cout << cur << " \n"[start == n];
    }
    return 0;
}
