#include<bits/stdc++.h>
using namespace std;

void solve(){
    int n;
    cin >> n;
    vector<vector<int>> g(n + 1);
    vector<int> indeg(n + 1, 0);
    vector<int> dp(n + 1, 1);  // dp[v]：理解第 v 章至少要读到第几轮
    for(int v = 1; v <= n; v++){
        int need;
        cin >> need;
        indeg[v] = need;
        for(int j = 0; j < need; j++){
            int u;
            cin >> u;
            g[u].push_back(v);  // 先懂 u 才能懂 v
        }
    }

    queue<int> q;
    for(int i = 1; i <= n; i++)
        if(indeg[i] == 0) q.push(i);

    int done = 0, ans = 0;
    while(!q.empty()){
        int u = q.front();
        q.pop();
        done++;
        ans = max(ans, dp[u]);
        for(int v : g[u]){
            // 前置编号更大：本轮读到 v 时 u 还没读完，只能等下一轮
            dp[v] = max(dp[v], dp[u] + (u > v ? 1 : 0));
            if(--indeg[v] == 0) q.push(v);
        }
    }

    if(done < n) cout << -1 << '\n';
    else cout << ans << '\n';
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T;
    cin >> T;
    while(T--) solve();
    return 0;
}
