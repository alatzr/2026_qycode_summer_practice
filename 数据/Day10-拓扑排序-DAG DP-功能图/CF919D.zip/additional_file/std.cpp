#include<bits/stdc++.h>
using namespace std;

const int N = 3e5 + 10;
vector<int> g[N];
int indeg[N];
int dp[N][26];  // dp[v][ch]：以 v 结尾的路径中字母 ch 的最多出现次数

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n, m;
    cin >> n >> m;
    string letters;
    cin >> letters;
    for(int i = 0; i < m; i++){
        int u, v;
        cin >> u >> v;
        g[u].push_back(v);
        indeg[v]++;
    }

    queue<int> q;
    for(int i = 1; i <= n; i++)
        if(indeg[i] == 0) q.push(i);

    int done = 0, ans = 0;
    while(!q.empty()){
        int u = q.front();
        q.pop();
        done++;
        dp[u][letters[u - 1] - 'a']++;  // 所有前驱都转移完，此刻结算 u 自己的字母
        for(int ch = 0; ch < 26; ch++) ans = max(ans, dp[u][ch]);
        for(int v : g[u]){
            for(int ch = 0; ch < 26; ch++)
                dp[v][ch] = max(dp[v][ch], dp[u][ch]);
            if(--indeg[v] == 0) q.push(v);
        }
    }

    if(done < n) cout << -1 << '\n';  // 有环：字母次数可以无限大
    else cout << ans << '\n';
    return 0;
}
