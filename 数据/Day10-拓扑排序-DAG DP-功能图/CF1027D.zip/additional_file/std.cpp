#include<bits/stdc++.h>
using namespace std;

const int N = 2e5 + 10;
int trapCost[N], nxt[N];
int state[N];  // 0 未访问，1 在本轮路径上，2 已处理完

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    for(int i = 1; i <= n; i++) cin >> trapCost[i];
    for(int i = 1; i <= n; i++) cin >> nxt[i];

    long long ans = 0;
    for(int i = 1; i <= n; i++){
        if(state[i] != 0) continue;
        int cur = i;
        while(state[cur] == 0){  // 沿唯一出边走，路径上的点标 1
            state[cur] = 1;
            cur = nxt[cur];
        }
        if(state[cur] == 1){     // 撞上本轮路径：发现一个新环
            int cycleMin = trapCost[cur];
            for(int p = nxt[cur]; p != cur; p = nxt[p])
                cycleMin = min(cycleMin, trapCost[p]);
            ans += cycleMin;
        }
        for(int p = i; state[p] == 1; p = nxt[p]) state[p] = 2;  // 本轮路径全部封存
    }
    cout << ans << '\n';
    return 0;
}
