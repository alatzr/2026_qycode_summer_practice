# CF1691D · Max GEQ Sum

- 难度：1800
- 标签：binary search、constructive algorithms、data structures、divide and conquer、implementation、two pointers
- 链接：https://codeforces.com/problemset/problem/1691/D
- 时间限制：1.5 seconds　内存限制：256 megabytes
- 出现位置：Day05-二分答案-ST表-RMQ/选做

## 英文原题面

### Statement

You are given an array $a$ of $n$ integers. You are asked to find out if the inequality $$\max(a_i, a_{i + 1}, \ldots, a_{j - 1}, a_{j}) \geq a_i + a_{i + 1} + \dots + a_{j - 1} + a_{j}$$ holds for all pairs of indices $(i, j)$, where $1 \leq i \leq j \leq n$.

### Input

Each test contains multiple test cases. The first line contains the number of test cases $t$ ($1 \le t \le 10^5$). Description of the test cases follows.
The first line of each test case contains a single integer $n$ ($1 \leq n \leq 2 \cdot 10^5$)  — the size of the array.
The next line of each test case contains $n$ integers $a_1, a_2, \ldots, a_n$ ($-10^9 \le a_i \le 10^9$).
It is guaranteed that the sum of $n$ over all test cases does not exceed $2 \cdot 10^5$.

### Output

For each test case, on a new line output "YES" if the condition is satisfied for the given array, and "NO" otherwise. You can print each letter in any case (upper or lower).

## 样例

### 样例 1

输入：

```text
3
4
-1 1 -1 2
5
-1 2 -3 2 -1
3
2 3 -1
```

输出：

```text
YES
YES
NO
```

## 样例解释（英文原文）

In test cases $1$ and $2$, the given condition is satisfied for all $(i, j)$ pairs. 
In test case $3$, the condition isn't satisfied for the pair $(1, 2)$ as $\max(2, 3)  \lt  2 + 3$.