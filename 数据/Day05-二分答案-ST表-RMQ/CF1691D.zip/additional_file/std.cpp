#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

struct STMax {
    vector<vector<ll>> st;
    vector<int> lg;
    void build(const vector<ll>& a) {
        int n = a.size();
        lg.assign(n + 1, 0);
        for (int i = 2; i <= n; i++) lg[i] = lg[i / 2] + 1;
        int K = lg[n] + 1;
        st.assign(K, vector<ll>(n));
        for (int i = 0; i < n; i++) st[0][i] = a[i];
        for (int j = 1; j < K; j++)
            for (int i = 0; i + (1 << j) <= n; i++)
                st[j][i] = max(st[j - 1][i], st[j - 1][i + (1 << (j - 1))]);
    }
    ll ask(int l, int r) {
        if (l > r) return LLONG_MIN / 4;
        int k = lg[r - l + 1];
        return max(st[k][l], st[k][r - (1 << k) + 1]);
    }
};

struct STMin {
    vector<vector<ll>> st;
    vector<int> lg;
    void build(const vector<ll>& a) {
        int n = a.size();
        lg.assign(n + 1, 0);
        for (int i = 2; i <= n; i++) lg[i] = lg[i / 2] + 1;
        int K = lg[n] + 1;
        st.assign(K, vector<ll>(n));
        for (int i = 0; i < n; i++) st[0][i] = a[i];
        for (int j = 1; j < K; j++)
            for (int i = 0; i + (1 << j) <= n; i++)
                st[j][i] = min(st[j - 1][i], st[j - 1][i + (1 << (j - 1))]);
    }
    ll ask(int l, int r) {
        if (l > r) return LLONG_MAX / 4;
        int k = lg[r - l + 1];
        return min(st[k][l], st[k][r - (1 << k) + 1]);
    }
};

bool ok(const vector<ll>& a) {
    int n = a.size();
    vector<ll> pre(n + 1);
    for (int i = 0; i < n; i++) pre[i + 1] = pre[i] + a[i];
    STMax stMax;
    STMin stMin;
    stMax.build(pre);
    stMin.build(pre);
    vector<int> L(n), R(n);
    vector<int> st;
    for (int i = 0; i < n; i++) {
        while (!st.empty() && a[st.back()] <= a[i]) st.pop_back();
        L[i] = st.empty() ? 0 : st.back() + 1;
        st.push_back(i);
    }
    st.clear();
    for (int i = n - 1; i >= 0; i--) {
        while (!st.empty() && a[st.back()] <= a[i]) st.pop_back();
        R[i] = st.empty() ? n - 1 : st.back() - 1;
        st.push_back(i);
    }
    for (int i = 0; i < n; i++) {
        ll mx = stMax.ask(i + 1, R[i] + 1);
        ll mn = stMin.ask(L[i], i);
        if (mx - mn > a[i]) return false;
    }
    return true;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T;
    cin >> T;
    while (T--) {
        int n;
        cin >> n;
        vector<ll> a(n);
        for (ll& x : a) cin >> x;
        cout << (ok(a) ? "YES" : "NO") << '\n';
    }
    return 0;
}
