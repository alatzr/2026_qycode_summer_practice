#!/usr/bin/env python3
"""Deterministic, format-valid test generator for CF1691D."""

import random
from pathlib import Path


LIMIT_N = 200_000
LIMIT_A = 1_000_000_000
OUT = Path(__file__).resolve().parent / "inputs"


def pack(cases):
    assert 1 <= len(cases) <= 100_000
    assert sum(map(len, cases)) <= LIMIT_N
    for values in cases:
        assert 1 <= len(values) <= LIMIT_N
        assert all(-LIMIT_A <= value <= LIMIT_A for value in values)
    return str(len(cases)) + "\n" + "".join(
        str(len(values)) + "\n" + " ".join(map(str, values)) + "\n"
        for values in cases
    )


def main():
    rng = random.Random(16912026)
    files = []

    files.append(pack([
        [-1, 1, -1, 2],
        [-1, 2, -3, 2, -1],
        [2, 3, -1],
    ]))
    files.append(pack([
        [0], [-LIMIT_A], [LIMIT_A], [1, 1], [-1, 1],
        [5, -5, 5], [5, -4, 5], [0, 0],
    ]))
    files.append(pack([
        [rng.randint(-20, 20) for _ in range(rng.randint(1, 12))]
        for _ in range(24)
    ]))
    files.append(pack([
        [-1] * 2_000,
        [1] * 2_000,
        [value for _ in range(1_000) for value in (LIMIT_A, -LIMIT_A)],
    ]))

    files.append(pack([[value for _ in range(LIMIT_N // 2) for value in (LIMIT_A, -LIMIT_A)]]))
    files.append(pack([[1] * LIMIT_N]))
    files.append(pack([[-LIMIT_A] * LIMIT_N]))
    files.append(pack([[rng.randint(-LIMIT_A, LIMIT_A) for _ in range(LIMIT_N)]]))
    files.append(pack([
        [1, 1] if i % 2 == 0 else [1, -1]
        for i in range(100_000)
    ]))
    files.append(pack([[LIMIT_A] + [-1] * (LIMIT_N - 1)]))

    OUT.mkdir(parents=True, exist_ok=True)
    for old in OUT.glob("*.in"):
        old.unlink()
    for index, content in enumerate(files, start=1):
        (OUT / f"{index}.in").write_text(content, encoding="ascii")
    print(f"CF1691D generated {len(files)} inputs")


if __name__ == "__main__":
    main()
