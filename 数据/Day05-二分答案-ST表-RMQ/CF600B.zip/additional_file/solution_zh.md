# CF600B Queries about less or equal elements 题解

## 题目大意

给数组 a 和 b，对 b 中每个元素 b_j，求 a 中有多少元素 ≤ b_j。

## 思路

- 将 a 排序后，`upper_bound(a, a+n, b_j)` 返回第一个大于 b_j 的位置，该位置下标即 ≤ b_j 的元素个数。
- 注意与 `lower_bound`（第一个 ≥）的区别：本题要"小于等于"，必须用 `upper_bound`。
- 值域含负数与 ±1e9，用 int 即可，个数不超过 2e5 不会溢出。

## 复杂度

时间 O((n + m) log n)，空间 O(n)。
