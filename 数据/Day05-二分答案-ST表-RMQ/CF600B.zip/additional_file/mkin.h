#!/usr/bin/env python3
# CF600B 数据生成器：python3 gen.py <case名> <seed>
# 各组用途：
#   min1        n=m=1 且取值域极值 -1e9 / 1e9
#   all_below   a 全部 > b：答案全 0；含极值边界
#   all_above   a 全部 <= b：答案全 n
#   all_equal   a、b 全相同值，考察 upper_bound 与重复值
#   rand_small* 小随机（含负数）供 bf 对拍
#   hit_edges   b 恰好取 a 中出现的值及其 ±1，密集命中二分边界
#   narrow_dup  值域极窄（[-3,3]）大量重复
#   full_rand   满量程 n=m=2e5 全值域随机
#   full_extreme 满量程且值集中在 ±1e9 两端与 0
import sys, random
V = 10**9

def emit(arr_a, arr_b):
    print(len(arr_a), len(arr_b))
    print(' '.join(map(str, arr_a)))
    print(' '.join(map(str, arr_b)))

def main():
    case, seed = sys.argv[1], int(sys.argv[2])
    rnd = random.Random(seed)
    if case == 'min1':
        emit([-V], [V])
    elif case == 'all_below':
        n = 100
        emit([rnd.randint(1, V) for _ in range(n)],
             [rnd.randint(-V, 0) for _ in range(n)])
    elif case == 'all_above':
        n = 100
        emit([rnd.randint(-V, 0) for _ in range(n)],
             [rnd.randint(1, V) for _ in range(n)])
    elif case == 'all_equal':
        emit([7]*200, [7]*100 + [6]*50 + [8]*50)
    elif case == 'rand_small':
        n = rnd.randint(1, 60); m = rnd.randint(1, 60)
        emit([rnd.randint(-100, 100) for _ in range(n)],
             [rnd.randint(-100, 100) for _ in range(m)])
    elif case == 'hit_edges':
        n = 5000
        arr_a = [rnd.randint(-10**6, 10**6) for _ in range(n)]
        arr_b = []
        for _ in range(5000):
            x = rnd.choice(arr_a)
            arr_b.append(x + rnd.choice([-1, 0, 1]))
        emit(arr_a, arr_b)
    elif case == 'narrow_dup':
        n = 100000
        emit([rnd.randint(-3, 3) for _ in range(n)],
             [rnd.randint(-4, 4) for _ in range(n)])
    elif case == 'full_rand':
        n = m = 200000
        emit([rnd.randint(-V, V) for _ in range(n)],
             [rnd.randint(-V, V) for _ in range(m)])
    elif case == 'full_extreme':
        n = m = 200000
        pool = [-V, -V+1, 0, V-1, V]
        emit([rnd.choice(pool) for _ in range(n)],
             [rnd.choice(pool) for _ in range(m)])
    else:
        raise SystemExit('unknown case: '+case)

if __name__ == '__main__':
    main()
