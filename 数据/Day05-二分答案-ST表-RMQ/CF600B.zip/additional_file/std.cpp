#include<bits/stdc++.h>
using namespace std;
// CF600B：排序后对每个 b_j 用 upper_bound 数 <= b_j 的个数
int n,m;
int arr[200005];
int main(){
    scanf("%d%d",&n,&m);
    for(int i=0;i<n;i++)scanf("%d",&arr[i]);
    sort(arr,arr+n);
    for(int j=0;j<m;j++){
        int query;scanf("%d",&query);
        // 第一个 > query 的位置即 <= query 的个数
        int cnt=upper_bound(arr,arr+n,query)-arr;
        printf("%d%c",cnt,j+1==m?'\n':' ');
    }
    return 0;
}
