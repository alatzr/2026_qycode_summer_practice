#!/usr/bin/env python3
# CF474B 数据生成器：python3 gen.py <case名> <seed>
# 各组用途：
#   min1        n=1,a=1,m=1 最小规模
#   single_max  n=1,a=1000 单堆极值，查两端
#   all_ones    全 1 堆，堆边界密集，查询覆盖每个编号
#   rand_small* 小随机（n,m<=50）供 bf 对拍
#   boundary    每个查询都打在堆边界（前缀和处与其 +1）
#   all_same    全部 a_i=1000，n=1000，sum 顶格 1e6
#   stairs      递增-递减锯齿结构
#   full_rand   满量程 n=1e5,m=1e5,sum 接近 1e6 随机
#   full_edge   满量程且查询全部为堆边界值
import sys, random

def emit(piles, queries):
    print(len(piles))
    print(' '.join(map(str, piles)))
    print(len(queries))
    print(' '.join(map(str, queries)))

def main():
    case, seed = sys.argv[1], int(sys.argv[2])
    rnd = random.Random(seed)
    if case == 'min1':
        emit([1], [1])
    elif case == 'single_max':
        emit([1000], [1, 1000, 500])
    elif case == 'all_ones':
        n = 100
        piles = [1]*n
        queries = list(range(1, n+1))
        rnd.shuffle(queries)
        emit(piles, queries)
    elif case == 'rand_small':
        n = rnd.randint(1, 50)
        piles = [rnd.randint(1, 30) for _ in range(n)]
        total = sum(piles)
        m = rnd.randint(1, 50)
        queries = [rnd.randint(1, total) for _ in range(m)]
        emit(piles, queries)
    elif case == 'boundary':
        n = 1000
        piles = [rnd.randint(1, 1000) for _ in range(n)]
        while sum(piles) > 10**6:
            piles = [rnd.randint(1, 900) for _ in range(n)]
        pref = []
        cur = 0
        for p in piles:
            cur += p
            pref.append(cur)
        queries = []
        for _ in range(1000):
            idx = rnd.randrange(n)
            # 打在边界：前缀和本身或前缀和 +1（不越界时）
            if rnd.random() < 0.5 or pref[idx] == cur:
                queries.append(pref[idx])
            else:
                queries.append(pref[idx]+1)
        emit(piles, queries)
    elif case == 'all_same':
        n = 1000
        piles = [1000]*n  # sum = 1e6 顶格
        queries = [rnd.randint(1, 10**6) for _ in range(1000)]
        queries[0] = 1; queries[1] = 10**6
        emit(piles, queries)
    elif case == 'stairs':
        n = 2000
        piles = [(i % 500) + 1 for i in range(n)]
        total = sum(piles)
        queries = [rnd.randint(1, total) for _ in range(2000)]
        emit(piles, queries)
    elif case == 'full_rand':
        n = 100000
        piles = [rnd.randint(1, 19) for _ in range(n)]  # 期望 sum ~1e6
        excess = sum(piles) - 10**6
        i = 0
        while excess > 0:  # 修正到 sum<=1e6
            cut = min(excess, piles[i]-1)
            piles[i] -= cut; excess -= cut; i += 1
        total = sum(piles)
        m = 100000
        queries = [rnd.randint(1, total) for _ in range(m)]
        queries[0] = 1; queries[1] = total
        emit(piles, queries)
    elif case == 'full_edge':
        n = 100000
        piles = [10]*n  # sum = 1e6 顶格
        pref = [10*(i+1) for i in range(n)]
        m = 100000
        queries = []
        for _ in range(m):
            idx = rnd.randrange(n)
            queries.append(pref[idx] if rnd.random() < 0.5 else max(1, pref[idx]-9))
        emit(piles, queries)
    else:
        raise SystemExit('unknown case: '+case)

if __name__ == '__main__':
    main()
