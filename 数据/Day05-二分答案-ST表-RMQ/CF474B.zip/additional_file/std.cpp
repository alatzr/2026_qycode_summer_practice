#include<bits/stdc++.h>
using namespace std;
// CF474B Worms：前缀和 + lower_bound 定位编号所在堆
int n,m;
long long pref[100005];
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++){
        int cnt;scanf("%d",&cnt);
        pref[i]=pref[i-1]+cnt; // 前缀和
    }
    scanf("%d",&m);
    while(m--){
        long long label;scanf("%lld",&label);
        // 第一个前缀和 >= label 的下标即所在堆
        int pos=lower_bound(pref+1,pref+n+1,label)-pref;
        printf("%d\n",pos);
    }
    return 0;
}
