#!/usr/bin/env python3
# CF2036C 数据生成器：python3 gen.py <case名> <seed>
# 约束：t<=1e4，sum|s|<=2e5，sum q<=2e5
# 各组用途：
#   hand_min      最小规模：|s|=1/2/3/4，恰好 "1100" 及其翻转
#   all_same      全 0 串与全 1 串，查询逐步拼出/破坏 1100
#   small_random  小随机多组，供 bf 对拍
#   struct_toggle 周期串 "1100..."，在窗口边界反复翻转
#   struct_overlap 长 1 段接长 0 段，只有边界一处 1100，查询集中在边界
#   max_multi     t=1e4 且 sum|s|、sum q 同时顶格 2e5
#   max_single    t=1，|s|=q=2e5 全随机
#   max_dense     t=1，s 为 "1100" 重复到 2e5，2e5 次针对性翻转
import random
import sys

MAXS = 200000
MAXQ = 200000


def emit(cases):
    # cases: [(s, [(pos, val), ...]), ...]
    out = [str(len(cases))]
    for s, queries in cases:
        out.append(s)
        out.append(str(len(queries)))
        for pos, val in queries:
            out.append(f"{pos} {val}")
    sys.stdout.write("\n".join(out) + "\n")


def hand_min(rng):
    cases = []
    cases.append(("0", [(1, 1), (1, 0)]))
    cases.append(("1", [(1, 1)]))
    cases.append(("11", [(2, 0), (1, 1)]))
    cases.append(("110", [(3, 0), (1, 0)]))
    # 恰好长度 4：拼出 1100 再破坏每一位
    cases.append(("1100", [(1, 1), (1, 0), (1, 1), (2, 0), (2, 1), (3, 1), (3, 0), (4, 1), (4, 0)]))
    cases.append(("0000", [(1, 1), (2, 1), (3, 0), (4, 0)]))
    cases.append(("1111", [(3, 0), (4, 0), (1, 0)]))
    emit(cases)


def all_same(rng):
    zeros = "0" * 60
    ones = "1" * 60
    build = [(10, 1), (11, 1), (12, 0), (13, 0), (12, 1), (12, 0)]
    destroy = [(30, 0), (31, 0), (30, 1), (32, 0), (33, 0), (31, 1)]
    cases = [(zeros, build), (ones, destroy)]
    emit(cases)


def small_random(rng, bias):
    t = rng.randint(15, 30)
    cases = []
    for _ in range(t):
        length = rng.randint(1, 12)
        if bias:
            # 偏向含 11 与 00 片段的串，更容易出现/接近 1100
            chars = []
            while len(chars) < length:
                chars.extend(rng.choice(["11", "00", "1", "0", "1100"]))
            s = "".join(chars)[:length]
        else:
            s = "".join(rng.choice("01") for _ in range(length))
        qn = rng.randint(1, 12)
        queries = [(rng.randint(1, length), rng.randint(0, 1)) for _ in range(qn)]
        cases.append((s, queries))
    emit(cases)


def struct_toggle(rng):
    s = "1100" * 50
    queries = []
    for _ in range(200):
        block = rng.randrange(50)
        offset = rng.randint(1, 4)
        pos = block * 4 + offset
        queries.append((pos, rng.randint(0, 1)))
    emit([(s, queries)])


def struct_overlap(rng):
    half = 100
    s = "1" * half + "0" * half
    queries = []
    for _ in range(200):
        pos = rng.randint(half - 3, half + 4)
        queries.append((pos, rng.randint(0, 1)))
    emit([(s, queries)])


def max_multi(rng):
    t = 10000
    lengths = [1] * t
    remain = MAXS - t
    for _ in range(remain):
        lengths[rng.randrange(t)] += 1
    qcounts = [1] * t
    remain_q = MAXQ - t
    for _ in range(remain_q):
        qcounts[rng.randrange(t)] += 1
    cases = []
    for length, qn in zip(lengths, qcounts):
        s = "".join(rng.choice("01") for _ in range(length))
        queries = [(rng.randint(1, length), rng.randint(0, 1)) for _ in range(qn)]
        cases.append((s, queries))
    emit(cases)


def max_single(rng):
    s = "".join(rng.choice("01") for _ in range(MAXS))
    queries = [(rng.randint(1, MAXS), rng.randint(0, 1)) for _ in range(MAXQ)]
    emit([(s, queries)])


def max_dense(rng):
    s = "1100" * (MAXS // 4)
    queries = []
    for _ in range(MAXQ):
        block = rng.randrange(MAXS // 4)
        offset = rng.randint(1, 4)
        queries.append((block * 4 + offset, rng.randint(0, 1)))
    emit([(s, queries)])


def main():
    case_name = sys.argv[1]
    seed = int(sys.argv[2])
    rng = random.Random(seed)
    table = {
        "hand_min": lambda: hand_min(rng),
        "all_same": lambda: all_same(rng),
        "small_random": lambda: small_random(rng, False),
        "small_random_bias": lambda: small_random(rng, True),
        "struct_toggle": lambda: struct_toggle(rng),
        "struct_overlap": lambda: struct_overlap(rng),
        "max_multi": lambda: max_multi(rng),
        "max_single": lambda: max_single(rng),
        "max_dense": lambda: max_dense(rng),
    }
    table[case_name]()


if __name__ == "__main__":
    main()
