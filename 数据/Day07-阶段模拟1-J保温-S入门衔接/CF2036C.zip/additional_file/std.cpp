#include<bits/stdc++.h>
using namespace std;

// 判断从下标 i 开始的 4 个字符是否为 "1100"
bool good(const string &s, int i){
    if(i < 0 || i + 3 >= (int)s.size()) return false;
    return s[i] == '1' && s[i + 1] == '1' && s[i + 2] == '0' && s[i + 3] == '0';
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int T;
    cin >> T;
    while(T--){
        string s;
        cin >> s;

        int cnt = 0; // 当前串中 "1100" 的出现次数
        for(int i = 0; i + 3 < (int)s.size(); i++){
            if(good(s, i)) cnt++;
        }

        int q;
        cin >> q;
        while(q--){
            int pos;
            char val;
            cin >> pos >> val;
            pos--; // 转成 0 下标

            // 单点修改只影响起点在 [pos-3, pos] 的窗口
            for(int i = pos - 3; i <= pos; i++){
                if(good(s, i)) cnt--;
            }

            s[pos] = val;

            for(int i = pos - 3; i <= pos; i++){
                if(good(s, i)) cnt++;
            }

            cout << (cnt > 0 ? "YES\n" : "NO\n");
        }
    }
    return 0;
}
