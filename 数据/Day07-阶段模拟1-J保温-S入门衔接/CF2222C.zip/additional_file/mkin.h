#!/usr/bin/env python3
# CF2222C Median Partition 数据生成器（多测）
# 约束：n 为奇数, 1<=n<5000；1<=a_i<=1e9；sum(n^2)<=5000^2
import os, random
OUT = os.path.join(os.path.dirname(__file__), "inputs")
os.makedirs(OUT, exist_ok=True)

sample1 = ("10\n5\n3 3 2 4 3\n7\n9 5 7 7 4 7 7\n9\n1 1 1 1 1 1 1 1 1\n1\n5\n"
           "3\n1 2 3\n3\n2 2 2\n5\n1 2 3 4 5\n5\n2 1 3 2 2\n7\n2 2 1 2 3 2 2\n"
           "9\n2 1 2 3 2 1 2 3 2\n")


def pack(cases):
    return f"{len(cases)}\n" + "".join(f"{len(a)}\n{' '.join(map(str,a))}\n" for a in cases)


def odd(rng, lo, hi):
    v = rng.randint(lo, hi)
    return v if v % 2 == 1 else v + 1


def rand_arr(rng, n, vmax):
    return [rng.randint(1, vmax) for _ in range(n)]


def main():
    rng = random.Random(22220)
    files = [sample1]
    files.append(pack([[7]]))                                   # n=1
    files.append(pack([[5, 5, 5, 5, 5]]))                       # 全相等 -> n
    files.append(pack([rand_arr(rng, odd(rng, 1, 9), 3) for _ in range(6)]))    # 小(对拍)
    files.append(pack([rand_arr(rng, odd(rng, 1, 25), 5) for _ in range(4)]))   # 小(对拍)
    files.append(pack([rand_arr(rng, odd(rng, 1, 99), 10) for _ in range(3)]))  # 中(对拍)
    # 满量程：单组 n≈4999（sum n^2 ~ 2.5e7 内），值域大
    files.append(pack([rand_arr(rng, 4999, 10**9)]))
    # 满量程：单组 n=4999 值域小(多重复，长段)
    files.append(pack([rand_arr(rng, 4999, 3)]))
    # 多组，sum n^2 受限：几组中等
    files.append(pack([rand_arr(rng, 1001, 100) for _ in range(20)]))
    for idx, content in enumerate(files, 1):
        with open(os.path.join(OUT, f"{idx}.in"), "w", newline="\n") as fh:
            fh.write(content)
    print(f"CF2222C 生成 {len(files)} 个输入")


if __name__ == "__main__":
    main()
