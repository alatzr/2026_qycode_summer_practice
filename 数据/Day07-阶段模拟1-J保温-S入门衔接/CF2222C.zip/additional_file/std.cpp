#include<bits/stdc++.h>
using namespace std;

void solve(){
    int n;
    cin >> n;
    vector<int> nums(n + 1);
    for(int i = 1; i <= n; i++) cin >> nums[i];
    // 每段中位数必须都等于整个数组的中位数 med
    vector<int> sortedNums(nums.begin() + 1, nums.end());
    sort(sortedNums.begin(), sortedNums.end());
    int med = sortedNums[(n - 1) / 2];
    // preGe[i]: 前 i 个数中 (>=med 记 +1, <med 记 -1) 的前缀和
    // preLe[i]: 前 i 个数中 (<=med 记 +1, >med 记 -1) 的前缀和
    vector<int> preGe(n + 1, 0), preLe(n + 1, 0);
    for(int i = 1; i <= n; i++){
        preGe[i] = preGe[i - 1] + (nums[i] >= med ? 1 : -1);
        preLe[i] = preLe[i - 1] + (nums[i] <= med ? 1 : -1);
    }
    const int NEG = -1e9;
    // dp[i]: 前 i 个数分成若干合法奇数段的最大段数
    vector<int> dp(n + 1, NEG);
    dp[0] = 0;
    for(int i = 1; i <= n; i++){
        for(int j = i - 1; j >= 0; j -= 2){    // 步长 2 保证段长 i-j 为奇数
            if(dp[j] == NEG) continue;
            if(preGe[i] - preGe[j] >= 1 && preLe[i] - preLe[j] >= 1)
                dp[i] = max(dp[i], dp[j] + 1);
        }
    }
    cout << dp[n] << '\n';                     // 整段划分必可行，dp[n] >= 1
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T;
    cin >> T;
    while(T--) solve();
    return 0;
}
