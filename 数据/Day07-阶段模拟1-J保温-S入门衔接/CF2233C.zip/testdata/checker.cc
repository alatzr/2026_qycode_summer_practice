#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;

// CF2233C 多解检验器：验证选手删除标记合法(长度=n、1 的个数<=k、仅含01)，
// 且删除后括号串代价(=最长合法括号子序列长度=2*匹配对数)不劣于标准答案
long long costOf(const string &s, const string &mark){
    long long open = 0, pairs = 0;
    for(size_t i = 0; i < s.size(); i++){
        if(mark[i] == '1') continue;
        if(s[i] == '(') open++;
        else if(open > 0){ open--; pairs++; }
    }
    return 2 * pairs;
}

int main(int argc, char *argv[]){
    registerTestlibCmd(argc, argv);
    int t = inf.readInt();
    for(int tc = 1; tc <= t; tc++){
        int n = inf.readInt();
        int k = inf.readInt();
        string s = inf.readToken();
        string pa = ouf.readToken();
        string ja = ans.readToken();
        if((int)pa.size() != n)
            quitf(_wa, "test %d: 选手标记长度 %d != n=%d", tc, (int)pa.size(), n);
        long long ones = 0;
        for(char c : pa){
            if(c != '0' && c != '1') quitf(_wa, "test %d: 标记含非法字符 '%c'", tc, c);
            if(c == '1') ones++;
        }
        if(ones > k) quitf(_wa, "test %d: 删除数 %lld 超过 k=%d", tc, ones, k);
        long long cp = costOf(s, pa), cj = costOf(s, ja);
        if(cp > cj) quitf(_wa, "test %d: 选手代价 %lld 劣于标准 %lld", tc, cp, cj);
    }
    quitf(_ok, "all %d cases optimal", t);
}
