#include<bits/stdc++.h>
using namespace std;

void solve(){
    int n, maxDel;
    cin >> n >> maxDel;
    string s;
    cin >> s;
    vector<int> removed(n, 0);         // removed[i]=1 表示第 i 个字符被删
    for(int step = 0; step < maxDel; step++){
        // 对剩余字符重做一次栈匹配
        vector<int> pairClose(n, -1);  // pairClose[i]: 位置 i 的 '(' 所配 ')' 的位置
        vector<int> stk;
        for(int i = 0; i < n; i++){
            if(removed[i]) continue;
            if(s[i] == '(') stk.push_back(i);
            else if(!stk.empty()){
                pairClose[stk.back()] = i;
                stk.pop_back();
            }
        }
        // 第一个未匹配 '(' 的位置；未匹配 '(' 全部在它之后
        int firstFreeOpen = stk.empty() ? n : stk[0];
        int delPos = -1;
        int lastClose = -1;            // 记录最后一个匹配 ')' 的位置
        for(int i = 0; i < n; i++){
            if(pairClose[i] == -1) continue;
            if(pairClose[i] < firstFreeOpen){
                delPos = i;            // 该对整体在未匹配 '(' 之前：删 '(' 无人补位
                break;
            }
            lastClose = max(lastClose, pairClose[i]);
        }
        // 所有匹配对都在未匹配 '(' 之后：删最后一个匹配 ')'，其后无未匹配 ')' 可补
        if(delPos == -1 && lastClose != -1) delPos = lastClose;
        if(delPos == -1) break;        // 已无匹配对，代价为 0，提前结束
        removed[delPos] = 1;
    }
    string mark(n, '0');
    for(int i = 0; i < n; i++){
        if(removed[i]) mark[i] = '1';
    }
    cout << mark << '\n';
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T;
    cin >> T;
    while(T--) solve();
    return 0;
}
