#!/usr/bin/env python3
# CF2233C Cost of a Bracket Sequence 数据生成器（多测，多解，用 checker 判定）
# 约束：1<=n<=5000；0<=k<=n；sum(n)<=5000；字符 '(' ')'
import os, random
OUT = os.path.join(os.path.dirname(__file__), "inputs")
os.makedirs(OUT, exist_ok=True)

sample1 = ("10\n2 1\n)(\n2 0\n()\n4 1\n(())\n4 1\n())(\n5 1\n((())\n"
           "6 2\n()()()\n6 2\n(()())\n6 2\n())(()\n7 3\n(()((()\n10 3\n(()())())(\n")


def rand_brackets(rng, n):
    return "".join(rng.choice("()") for _ in range(n))


def one(n, k, s):
    return f"{n} {k}\n{s}\n"


def pack(cases):
    return f"{len(cases)}\n" + "".join(one(*c) for c in cases)


def main():
    rng = random.Random(22330)
    files = [sample1]
    files.append(pack([(1, 0, "(")]))                              # 最小
    files.append(pack([(1, 1, ")")]))                              # 可删单个
    # 小(供 bf_cost 枚举验证，n<=12)
    files.append(pack([(n := rng.randint(1, 10), rng.randint(0, n), rand_brackets(rng, n)) for _ in range(8)]))
    files.append(pack([(n := rng.randint(1, 12), rng.randint(0, n), rand_brackets(rng, n)) for _ in range(6)]))
    files.append(pack([(12, 0, "(())(())(())"), (12, 3, "())(())(()(")]))  # k=0 与结构化
    # 中等
    files.append(pack([(200, 50, rand_brackets(rng, 200)), (300, 0, rand_brackets(rng, 300))]))
    # 满量程：单组 n=5000
    files.append(pack([(5000, 2500, rand_brackets(rng, 5000))]))
    # 满量程：n=5000, k=0（不能删）
    files.append(pack([(5000, 0, rand_brackets(rng, 5000))]))
    # 满量程：n=5000, k=n（可全删->代价0）
    files.append(pack([(5000, 5000, rand_brackets(rng, 5000))]))
    # 多组总和 5000
    files.append(pack([(1000, 200, rand_brackets(rng, 1000)) for _ in range(5)]))
    for idx, content in enumerate(files, 1):
        with open(os.path.join(OUT, f"{idx}.in"), "w", newline="\n") as fh:
            fh.write(content)
    print(f"CF2233C 生成 {len(files)} 个输入")


if __name__ == "__main__":
    main()
