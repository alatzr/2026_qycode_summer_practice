#!/usr/bin/env python3
# CF1905C Largest Subsequence 数据生成器（多测）
# 约束：n<=2e5；sum(n)<=2e5；小写字母
import os, random
OUT = os.path.join(os.path.dirname(__file__), "inputs")
os.makedirs(OUT, exist_ok=True)

sample1 = ("6\n5\naaabc\n3\nacb\n3\nbac\n4\nzbca\n15\nczddeneeeemigec\n13\ncdefmopqsvxzz\n")


def pack(cases):
    return f"{len(cases)}\n" + "".join(f"{len(s)}\n{s}\n" for s in cases)


def rand_str(rng, n, alpha):
    return "".join(rng.choice(alpha) for _ in range(n))


def main():
    rng = random.Random(19050)
    files = [sample1]
    files.append(pack(["a"]))                              # 最小
    files.append(pack(["ba"]))                             # 一次操作
    files.append(pack(["cba"]))                            # 需判 -1 情形
    files.append(pack([rand_str(rng, rng.randint(1, 6), "ab") for _ in range(8)]))   # 小(对拍)
    files.append(pack([rand_str(rng, rng.randint(1, 10), "abc") for _ in range(10)]))# 小(对拍)
    files.append(pack([rand_str(rng, rng.randint(1, 40), "abcd") for _ in range(6)]))# 中(对拍)
    files.append(pack(["".join(sorted(rand_str(rng, 100, "abcde")))]))               # 已有序->0
    files.append(pack([rand_str(rng, 200000, "abcdefghijklmnopqrstuvwxyz")]))        # 满量程随机
    files.append(pack([rand_str(rng, 200000, "ba")]))                                # 满量程双字符
    files.append(pack([rand_str(rng, rng.randint(1, 100), "abc") for _ in range(2000)]))  # t 大
    for idx, content in enumerate(files, 1):
        with open(os.path.join(OUT, f"{idx}.in"), "w", newline="\n") as fh:
            fh.write(content)
    print(f"CF1905C 生成 {len(files)} 个输入")


if __name__ == "__main__":
    main()
