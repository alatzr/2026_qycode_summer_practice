#include<bits/stdc++.h>
using namespace std;

void solve(){
    int n;
    string s;
    cin >> n >> s;
    // 从右往左取"后缀最大值链"，即字典序最大子序列的下标
    vector<int> pos;
    char sufMax = 0;
    for(int i = n - 1; i >= 0; i--){
        if(s[i] >= sufMax){
            sufMax = s[i];
            pos.push_back(i);
        }
    }
    reverse(pos.begin(), pos.end());   // 下标转为从小到大
    int len = (int)pos.size();
    string chain;                      // 子序列本身，非升序
    for(int p : pos) chain += s[p];
    int cntMax = 0;                    // 链中等于最大字符的个数
    for(char ch : chain){
        if(ch == chain[0]) cntMax++;
    }
    // 把链排成升序放回原位置，模拟"转完所有操作"后的最终串
    reverse(chain.begin(), chain.end());
    for(int i = 0; i < len; i++) s[pos[i]] = chain[i];
    if(is_sorted(s.begin(), s.end())) cout << len - cntMax << '\n';
    else cout << -1 << '\n';
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T;
    cin >> T;
    while(T--) solve();
    return 0;
}
