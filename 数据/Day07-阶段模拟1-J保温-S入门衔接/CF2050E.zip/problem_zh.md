# CF2050E · Three Strings

- 难度：1500
- 标签：dp、implementation、strings
- 链接：https://codeforces.com/problemset/problem/2050/E
- 时间限制：2.5 seconds　内存限制：256 megabytes
- 出现位置：Day07-阶段模拟1-J保温-S入门衔接

## 中文题意

给定三个小写字母串 $a$、$b$、$c$，其中 $|c| = |a| + |b|$。串 $c$ 由 $a$ 和 $b$ 的字符按各自的相对顺序交织而成，但在交织后允许把 $c$ 的某些位置改成别的字符。

问：$c$ 中至少有多少个位置是被改动过的？等价地，选一种把 $a$、$b$ 交织成长度 $|c|$ 的方式，使与 $c$ 对应位置不相同的位置数最少，输出这个最小值。

本题包含 $t$ 组测试数据。

## 输入格式（中文）

第一行一个整数 $t$（$1 \le t \le 10^3$）——测试数据组数。

每组第一行字符串 $a$（$1 \le |a| \le 10^3$），第二行字符串 $b$（$1 \le |b| \le 10^3$），第三行字符串 $c$（$|c| = |a|+|b|$），均为小写字母。

保证所有数据的 $|a|$ 之和不超过 $2\cdot10^3$，$|b|$ 之和不超过 $2\cdot10^3$。

## 输出格式（中文）

对每组数据输出一行一个整数——$c$ 中最少被改动的位置数。

## 样例

### 样例 1

输入：

```text
7
a
b
cb
ab
cd
acbd
ab
ba
aabb
xxx
yyy
xyxyxy
a
bcd
decf
codes
horse
codeforces
egg
annie
egaegaeg
```

输出：

```text
1
0
2
0
3
2
3
```