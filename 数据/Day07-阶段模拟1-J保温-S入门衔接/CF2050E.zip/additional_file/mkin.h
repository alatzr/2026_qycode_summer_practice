#!/usr/bin/env python3
# CF2050E Three Strings 数据生成器（多测）
# 约束：1<=|a|,|b|<=1e3；|c|=|a|+|b|；sum|a|<=2e3, sum|b|<=2e3；小写字母
import os, random
OUT = os.path.join(os.path.dirname(__file__), "inputs")
os.makedirs(OUT, exist_ok=True)

sample1 = ("7\na\nb\ncb\nab\ncd\nacbd\nab\nba\naabb\nxxx\nyyy\nxyxyxy\n"
           "a\nbcd\ndecf\ncodes\nhorse\ncodeforces\negg\nannie\negaegaeg\n")


def rand_str(rng, n, alpha):
    return "".join(rng.choice(alpha) for _ in range(n))


def interleave(rng, a, b, alpha, noise):
    # 按相对顺序交织 a,b 得到 c，再随机扰动 noise 个位置
    i = j = 0; c = []
    while i < len(a) or j < len(b):
        if j >= len(b) or (i < len(a) and rng.random() < 0.5):
            c.append(a[i]); i += 1
        else:
            c.append(b[j]); j += 1
    c = list("".join(c))
    for _ in range(noise):
        p = rng.randrange(len(c))
        c[p] = rng.choice(alpha)
    return "".join(c)


def pack(cases):
    return f"{len(cases)}\n" + "".join(f"{a}\n{b}\n{c}\n" for a, b, c in cases)


def main():
    rng = random.Random(20500)
    files = [sample1]
    files.append(pack([("a", "a", "aa")]))                      # 最小
    files.append(pack([("a", "a", "bb")]))                      # 全改
    small = []
    for _ in range(6):
        a = rand_str(rng, rng.randint(1, 5), "ab")
        b = rand_str(rng, rng.randint(1, 5), "ab")
        small.append((a, b, interleave(rng, a, b, "ab", rng.randint(0, 2))))
    files.append(pack(small))                                   # 小(对拍)
    small2 = []
    for _ in range(5):
        a = rand_str(rng, rng.randint(1, 8), "abc")
        b = rand_str(rng, rng.randint(1, 8), "abc")
        small2.append((a, b, interleave(rng, a, b, "abc", rng.randint(0, 3))))
    files.append(pack(small2))                                  # 小(对拍)
    # 满量程：单组 |a|=|b|=1000
    a = rand_str(rng, 1000, "abcdefghijklmnopqrstuvwxyz")
    b = rand_str(rng, 1000, "abcdefghijklmnopqrstuvwxyz")
    files.append(pack([(a, b, interleave(rng, a, b, "abcdefghijklmnopqrstuvwxyz", 300))]))
    # 满量程：多组总和顶格
    cases = []
    for _ in range(4):
        a = rand_str(rng, 500, "ab"); b = rand_str(rng, 500, "ab")
        cases.append((a, b, interleave(rng, a, b, "ab", 200)))
    files.append(pack(cases))
    for idx, content in enumerate(files, 1):
        with open(os.path.join(OUT, f"{idx}.in"), "w", newline="\n") as fh:
            fh.write(content)
    print(f"CF2050E 生成 {len(files)} 个输入")


if __name__ == "__main__":
    main()
