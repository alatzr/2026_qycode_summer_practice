#include<bits/stdc++.h>
using namespace std;

void solve(){
    string strA, strB, strC;           // 对应题面中的 a、b、c
    cin >> strA >> strB >> strC;
    int lenA = strA.size(), lenB = strB.size();
    const int INF = 1e9;
    // dp[i][j]: strA 取走前 i 个、strB 取走前 j 个，拼出 strC 前 i+j 位的最小修改数
    vector<vector<int>> dp(lenA + 1, vector<int>(lenB + 1, INF));
    dp[0][0] = 0;
    for(int i = 0; i <= lenA; i++){
        for(int j = 0; j <= lenB; j++){
            if(dp[i][j] == INF) continue;
            int pos = i + j;           // strC 中下一个要拼的位置(0 下标)
            if(i < lenA)
                dp[i + 1][j] = min(dp[i + 1][j], dp[i][j] + (strA[i] != strC[pos]));
            if(j < lenB)
                dp[i][j + 1] = min(dp[i][j + 1], dp[i][j] + (strB[j] != strC[pos]));
        }
    }
    cout << dp[lenA][lenB] << '\n';
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T;
    cin >> T;
    while(T--) solve();
    return 0;
}
