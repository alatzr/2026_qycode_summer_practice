#!/usr/bin/env python3
# CF1996C Sort 数据生成器（多测）
# 约束：n,q<=2e5；sum(n)+sum(q)<=2e5；小写字母
import os, random
OUT = os.path.join(os.path.dirname(__file__), "inputs")
os.makedirs(OUT, exist_ok=True)

sample1 = ("3\n5 3\nabcde\nedcba\n1 5\n1 4\n3 3\n"
           "4 2\nzzde\nazbe\n1 3\n1 4\n"
           "6 3\nuwuwuw\nwuwuwu\n2 4\n1 3\n1 6\n")


def one(n, q, a, b, qs):
    lines = [f"{n} {q}", a, b] + [f"{l} {r}" for l, r in qs]
    return "\n".join(lines) + "\n"


def pack(cases):
    return f"{len(cases)}\n" + "".join(one(*c) for c in cases)


def rand_case(rng, n, q, alpha):
    a = "".join(rng.choice(alpha) for _ in range(n))
    b = "".join(rng.choice(alpha) for _ in range(n))
    qs = []
    for _ in range(q):
        l = rng.randint(1, n); r = rng.randint(l, n)
        qs.append((l, r))
    return (n, q, a, b, qs)


def main():
    rng = random.Random(19960)
    files = [sample1]
    files.append(pack([(1, 1, "a", "a", [(1, 1)])]))               # 最小
    files.append(pack([(1, 1, "a", "b", [(1, 1)])]))               # 单字符需改
    files.append(pack([rand_case(rng, 5, 5, "ab")]))               # 小(对拍)
    files.append(pack([rand_case(rng, 20, 20, "abc") for _ in range(3)]))  # 小(对拍)
    files.append(pack([rand_case(rng, 200, 200, "abcde")]))        # 中(对拍)
    files.append(pack([rand_case(rng, 100000, 100000, "abcdefghijklmnopqrstuvwxyz")]))  # 满量程
    # 满量程：多组总和 2e5
    files.append(pack([rand_case(rng, 50000, 50000, "abc"), rand_case(rng, 50000, 50000, "xyz")]))
    # t 顶格(1000 组小数据)
    files.append(pack([rand_case(rng, rng.randint(1, 100), rng.randint(1, 100), "ab") for _ in range(1000)]))
    for idx, content in enumerate(files, 1):
        with open(os.path.join(OUT, f"{idx}.in"), "w", newline="\n") as fh:
            fh.write(content)
    print(f"CF1996C 生成 {len(files)} 个输入")


if __name__ == "__main__":
    main()
