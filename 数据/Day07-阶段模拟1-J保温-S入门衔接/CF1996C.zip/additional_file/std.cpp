#include<bits/stdc++.h>
using namespace std;

void solve(){
    int n, q;
    cin >> n >> q;
    string src, tgt;                   // src 为可修改串，tgt 为目标串
    cin >> src >> tgt;
    // preSrc[i][ch]: src 前 i 个字符中字母 ch 的出现次数，preTgt 同理
    vector<array<int, 26>> preSrc(n + 1), preTgt(n + 1);
    preSrc[0].fill(0);
    preTgt[0].fill(0);
    for(int i = 1; i <= n; i++){
        preSrc[i] = preSrc[i - 1];
        preTgt[i] = preTgt[i - 1];
        preSrc[i][src[i - 1] - 'a']++;
        preTgt[i][tgt[i - 1] - 'a']++;
    }
    while(q--){
        int l, r;
        cin >> l >> r;
        int diff = 0;                  // 两区间 26 个字母数量差的绝对值之和
        for(int ch = 0; ch < 26; ch++){
            int cntSrc = preSrc[r][ch] - preSrc[l - 1][ch];
            int cntTgt = preTgt[r][ch] - preTgt[l - 1][ch];
            diff += abs(cntSrc - cntTgt);
        }
        cout << diff / 2 << '\n';      // 一次修改同时消掉一多一少
    }
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T;
    cin >> T;
    while(T--) solve();
    return 0;
}
