#include<bits/stdc++.h>
using namespace std;
// n 为奇数无解。否则统计子树大小为偶数的边数(去根)，这些边可同时切开。BFS 逆序求子树大小。
const int N = 1e5 + 10;
int n, siz[N], par[N];
vector<int> g[N];
int main(){
    ios::sync_with_stdio(false); cin.tie(nullptr);
    cin >> n;
    for(int i = 1; i < n; i++){ int u, v; cin >> u >> v; g[u].push_back(v); g[v].push_back(u); }
    if(n % 2 == 1){ cout << -1 << '\n'; return 0; }
    vector<int> order; order.reserve(n);
    vector<char> vis(n + 1, 0);
    queue<int> q; q.push(1); vis[1] = 1; par[1] = 0;
    while(!q.empty()){
        int u = q.front(); q.pop(); order.push_back(u);
        for(int v : g[u]) if(!vis[v]){ vis[v] = 1; par[v] = u; q.push(v); }
    }
    for(int i = 1; i <= n; i++) siz[i] = 1;
    for(int i = (int)order.size() - 1; i >= 0; i--){ int u = order[i]; if(u != 1) siz[par[u]] += siz[u]; }
    int ans = 0;
    for(int u = 2; u <= n; u++) if(siz[u] % 2 == 0) ans++;
    cout << ans << '\n';
    return 0;
}
