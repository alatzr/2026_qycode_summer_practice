#include<bits/stdc++.h>
using namespace std;
// 迭代 DFS：栈存 (点, 父亲, 到此为止连续猫数)。连续猫超 m 则整棵子树剪掉。
// 统计到达得了的叶子(非根)数量。
const int N = 1e5 + 10;
int n, m, hasCat[N];
vector<int> g[N];
int main(){
    ios::sync_with_stdio(false); cin.tie(nullptr);
    cin >> n >> m;
    for(int i = 1; i <= n; i++) cin >> hasCat[i];
    for(int i = 1; i < n; i++){ int u, v; cin >> u >> v; g[u].push_back(v); g[v].push_back(u); }
    int ans = 0;
    vector<array<int,3>> stk;
    stk.push_back({1, 0, 0});
    while(!stk.empty()){
        auto top = stk.back(); stk.pop_back();
        int u = top[0], par = top[1], cr = top[2];
        cr = hasCat[u] ? cr + 1 : 0;
        if(cr > m) continue;               // 剪枝：整棵子树不可达
        bool isLeaf = true;
        for(int v : g[u]) if(v != par){ isLeaf = false; stk.push_back({v, u, cr}); }
        if(isLeaf && u != 1) ans++;
    }
    cout << ans << '\n';
    return 0;
}
