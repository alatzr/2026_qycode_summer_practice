#include<bits/stdc++.h>
using namespace std;
// 用 k 色能让 leafCnt[u]<=k 的点全开心，故排序后第 k 小的 leafCnt 即第 k 个答案。
// BFS 逆序累加叶子数(迭代，防链形爆栈)。
const int N = 1e5 + 10;
int n, leafCnt[N];
vector<int> children[N];
int main(){
    ios::sync_with_stdio(false); cin.tie(nullptr);
    cin >> n;
    for(int i = 2; i <= n; i++){ int par; cin >> par; children[par].push_back(i); }
    vector<int> order; order.reserve(n);
    queue<int> q; q.push(1);
    while(!q.empty()){ int u = q.front(); q.pop(); order.push_back(u); for(int v : children[u]) q.push(v); }
    for(int i = (int)order.size() - 1; i >= 0; i--){
        int u = order[i];
        if(children[u].empty()) leafCnt[u] = 1;
        else { int s = 0; for(int v : children[u]) s += leafCnt[v]; leafCnt[u] = s; }
    }
    sort(leafCnt + 1, leafCnt + n + 1);
    for(int i = 1; i <= n; i++) cout << leafCnt[i] << " \n"[i == n];
    return 0;
}
