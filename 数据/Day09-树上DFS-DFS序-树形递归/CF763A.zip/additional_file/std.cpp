#include<bits/stdc++.h>
using namespace std;
// 找一条两端异色的冲突边，根必是其某端点；迭代验证以该端点为根时各部分是否单色。
const int N = 1e5 + 10;
int n, color[N];
vector<int> g[N];

bool compSame(int start, int blocked, int col){
    vector<pair<int,int>> stk; stk.push_back({start, blocked});
    while(!stk.empty()){
        auto cur = stk.back(); stk.pop_back();
        int u = cur.first, par = cur.second;
        if(color[u] != col) return false;
        for(int v : g[u]) if(v != par) stk.push_back({v, u});
    }
    return true;
}
bool goodRoot(int root){
    for(int v : g[root]) if(!compSame(v, root, color[v])) return false;
    return true;
}
int main(){
    ios::sync_with_stdio(false); cin.tie(nullptr);
    cin >> n;
    vector<pair<int,int>> edges(max(0, n - 1));
    for(auto &[u, v] : edges){ cin >> u >> v; g[u].push_back(v); g[v].push_back(u); }
    for(int i = 1; i <= n; i++) cin >> color[i];
    int eu = -1, ev = -1;
    for(auto &[u, v] : edges) if(color[u] != color[v]){ eu = u; ev = v; break; }
    if(eu == -1) cout << "YES\n" << 1 << '\n';
    else if(goodRoot(eu)) cout << "YES\n" << eu << '\n';
    else if(goodRoot(ev)) cout << "YES\n" << ev << '\n';
    else cout << "NO\n";
    return 0;
}
