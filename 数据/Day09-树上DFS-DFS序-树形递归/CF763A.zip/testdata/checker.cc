#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;
// 763A 多解校验：可行 <=> 存在一个顶点覆盖所有"异色边"。
// YES r 合法 <=> r 是所有异色边的端点；NO 合法 <=> 确实无这样的顶点。
int main(int argc, char* argv[]){
    registerTestlibCmd(argc, argv);
    int n = inf.readInt();
    vector<pair<int,int>> edges;
    for(int i = 0; i < n - 1; i++){ int u = inf.readInt(), v = inf.readInt(); edges.push_back({u, v}); }
    vector<int> col(n + 1);
    for(int i = 1; i <= n; i++) col[i] = inf.readInt();
    vector<pair<int,int>> conf;
    for(auto &e : edges) if(col[e.first] != col[e.second]) conf.push_back(e);
    auto coversAll = [&](int r){ for(auto &e : conf) if(e.first != r && e.second != r) return false; return true; };
    bool feasible = conf.empty() || coversAll(conf[0].first) || coversAll(conf[0].second);
    string verdict = ouf.readToken();
    for(auto &c : verdict) c = toupper(c);
    if(verdict == "NO"){
        if(feasible) quitf(_wa, "answered NO but a valid root exists");
        quitf(_ok, "correctly NO");
    }
    if(verdict != "YES") quitf(_wa, "expected YES or NO, got %s", verdict.c_str());
    if(!feasible) quitf(_wa, "answered YES but no valid root exists");
    int r = ouf.readInt(1, n, "root");
    if(!coversAll(r)) quitf(_wa, "root %d does not cover all conflict edges", r);
    quitf(_ok, "valid root %d", r);
}
