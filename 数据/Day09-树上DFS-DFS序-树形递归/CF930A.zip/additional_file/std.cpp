#include<bits/stdc++.h>
using namespace std;
// 同层苹果两两抵消，只剩奇偶性；答案 = 各深度点数为奇数的层数。BFS 迭代求深度。
int main(){
    ios::sync_with_stdio(false); cin.tie(nullptr);
    int n; cin >> n;
    vector<vector<int>> children(n + 1);
    for(int i = 2; i <= n; i++){ int par; cin >> par; children[par].push_back(i); }
    vector<int> depth(n + 1, 0), cntAtDepth(n + 1, 0);
    queue<int> q; q.push(1); cntAtDepth[0] = 1;
    while(!q.empty()){
        int u = q.front(); q.pop();
        for(int v : children[u]){ depth[v] = depth[u] + 1; cntAtDepth[depth[v]]++; q.push(v); }
    }
    int ans = 0;
    for(int d = 0; d <= n; d++) ans += cntAtDepth[d] & 1;
    cout << ans << '\n';
    return 0;
}
