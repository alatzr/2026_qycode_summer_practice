# CF930A · Peculiar apple-tree

- 难度：1500
- 标签：dfs and similar、graphs、trees
- 链接：https://codeforces.com/problemset/problem/930/A
- 时间限制：1 second　内存限制：256 megabytes
- 出现位置：Day09-树上DFS-DFS序-树形递归

## 中文题意

以下为官方英文题意（课堂讲解时请要求学生能用自己的话复述条件与目标）。

In Arcady's garden there grows a peculiar apple-tree that fruits one time per year. Its peculiarity can be explained in following way: there are n inflorescences, numbered from 1 to n. Inflorescence number 1 is situated near base of tree and any other inflorescence with number i (i > 1) is situated at the top of branch, which bottom is pi-th inflorescence and pi < i.
Once tree starts fruiting, there appears exactly one apple in each inflorescence. The same moment as apples appear, they start to roll down along branches to the very base of tree. Each second all apples, except ones in first inflorescence simultaneously roll down one branch closer to tree base, e.g. apple in a-th inflorescence gets to pa-th inflorescence. Apples that end up in first inflorescence are gathered by Arcady in exactly the same moment. Second peculiarity of this tree is that once two apples are in same inflorescence they annihilate. This happens with each pair of apples, e.g. if there are 5 apples in same inflorescence in same time, only one will not be annihilated and if there are 8 apples, all apples will be annihilated. Thus, there can be no more than one apple in each inflorescence in each moment of time.
Help Arcady with counting number of apples he will be able to collect from first inflorescence during one harvest.

**Note（官方）**：
In first example Arcady will be able to collect only one apple, initially situated in 1st inflorescence. In next second apples from 2nd and 3rd inflorescences will roll down and annihilate, and Arcady won't be able to collect them.
In the second example Arcady will be able to collect 3 apples. First one is one initially situated in first inflorescence. In a second apple from 2nd inflorescence will roll down to 1st (Arcady will collect it) and apples from 3rd, 4th, 5th inflorescences will roll down to 2nd. Two of them will annihilate and one not annihilated will roll down from 2-nd inflorescence to 1st one in the next second and Arcady will collect it.


## 输入格式（中文）

First line of input contains single integer number n (2 ≤ n ≤ 100 000)  — number of inflorescences.
Second line of input contains sequence of n - 1 integer numbers p2, p3, ..., pn (1 ≤ pi < i), where pi is number of inflorescence into which the apple from i-th inflorescence rolls down.


## 输出格式（中文）

Single line of output should contain one integer number: amount of apples that Arcady will be able to collect from first inflorescence during one harvest.

## 样例

### 样例 1

输入：

```text
3
1 1
```

输出：

```text
1
```

### 样例 2

输入：

```text
5
1 2 2 2
```

输出：

```text
3
```

### 样例 3

输入：

```text
18
1 1 1 4 4 3 2 2 2 10 8 9 9 9 10 10 4
```

输出：

```text
4
```