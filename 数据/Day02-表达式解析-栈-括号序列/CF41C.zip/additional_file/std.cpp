#include<bits/stdc++.h>
using namespace std;

const string BAD = "~";
string s;

bool better(const string& a, const string& b){
    if(a == BAD) return false;
    if(b == BAD) return true;
    if(a.size() != b.size()) return a.size() < b.size();
    return a < b;
}

bool okEmail(const string& t){
    if(t.empty()) return false;
    if(t[0] == '.' || t[0] == '@' || t.back() == '.' || t.back() == '@') return false;
    return count(t.begin(), t.end(), '@') == 1;
}

string dpLeft[105][105];
string dpRight[105][105];

string expandLeft(int l, int r){
    if(l >= r) return "";
    if(dpLeft[l][r] != "") return dpLeft[l][r];
    string best = BAD;
    string t1 = string(1, s[l]) + expandLeft(l + 1, r);
    if(better(t1, best)) best = t1;
    if(l > 0 && l + 3 <= r && s.compare(l, 3, "dot") == 0){
        string t2 = "." + expandLeft(l + 3, r);
        if(better(t2, best)) best = t2;
    }
    return dpLeft[l][r] = best;
}

string expandRight(int l, int r){
    if(l >= r) return "";
    if(dpRight[l][r] != "") return dpRight[l][r];
    string best = BAD;
    string t1 = string(1, s[l]) + expandRight(l + 1, r);
    if(t1 != BAD && t1.back() != '.') best = t1;
    if(l + 3 <= r && s.compare(l, 3, "dot") == 0){
        string inner = expandRight(l + 3, r);
        if(inner != BAD){
            string t2 = "." + inner;
            if(t2.back() != '.') best = t2;
        }
    }
    return dpRight[l][r] = best;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string in;
    cin >> in;
    if(!in.empty() && in.back() == '\r') in.pop_back();

    string ans;
    for(int i = 0; i + 1 < (int)in.size(); i++){
        if(in.compare(i, 2, "at") != 0) continue;
        s = in;
        memset(dpLeft, 0, sizeof dpLeft);
        memset(dpRight, 0, sizeof dpRight);
        string left = expandLeft(0, i);
        string right = expandRight(i + 2, (int)s.size());
        if(left == BAD || right == BAD) continue;
        string cand = left + "@" + right;
        if(!okEmail(cand)) continue;
        if(ans.empty() || better(cand, ans)) ans = cand;
    }
    cout << ans << '\n';
    return 0;
}
