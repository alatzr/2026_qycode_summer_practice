#include<bits/stdc++.h>
using namespace std;

bool isleft(char c){
    return c == '(' || c == '[';
}

bool match(char l, char r){
    return (l == '(' && r == ')') || (l == '[' && r == ']');
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string s;
    cin >> s;
    int n = (int)s.size();

    vector<int> pre(n + 1, 0);
    for(int i = 0; i < n; i++){
        pre[i + 1] = pre[i] + (s[i] == '[');
    }

    stack<int> st;
    st.push(-1);

    int best = 0;
    int L = 0, R = -1;

    for(int i = 0; i < n; i++){
        if(isleft(s[i])){
            st.push(i);
        }else{
            if(st.top() != -1 && match(s[st.top()], s[i])){
                st.pop();
                int l = st.top() + 1;
                int cnt = pre[i + 1] - pre[l];
                if(cnt > best || (cnt == best && i - l > R - L)){
                    best = cnt;
                    L = l;
                    R = i;
                }
            }else{
                st.push(i);
            }
        }
    }

    cout << best << '\n';
    if(best > 0){
        for(int i = L; i <= R; i++) cout << s[i];
    }
    cout << '\n';
    return 0;
}
