#include<bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string s;
    cin >> s;

    vector<int> a;
    int x = 0; // 当前正在解析的数字

    for(int i = 0; i <= (int)s.size(); i++){
        if(i == (int)s.size() || s[i] == ','){
            a.push_back(x); // 一个数字解析完成
            x = 0;
        }else{
            x = x * 10 + (s[i] - '0');
        }
    }

    sort(a.begin(), a.end());
    a.erase(unique(a.begin(), a.end()), a.end()); // 去重

    vector<pair<int,int>> seg;

    for(int i = 0; i < (int)a.size(); ){
        int l = a[i], r = a[i];
        int j = i + 1;

        while(j < (int)a.size() && a[j] == r + 1){
            r = a[j];
            j++;
        }

        seg.push_back({l, r});
        i = j;
    }

    for(int i = 0; i < (int)seg.size(); i++){
        if(i) cout << ',';

        int l = seg[i].first;
        int r = seg[i].second;

        if(l == r) cout << l;
        else cout << l << '-' << r;
    }
    cout << '\n';

    return 0;
}
