#include<bits/stdc++.h>
using namespace std;

const long long LIM = (1LL << 32); // 超过 2^32-1 等价于达到 2^32

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;

    stack<long long> st;
    st.push(1); // 初始没有循环，当前倍数是 1

    long long ans = 0;

    for(int i = 1; i <= n; i++){
        string op;
        cin >> op;

        if(op == "add"){
            ans += st.top(); // 当前 add 会执行 st.top() 次

            if(ans >= LIM){
                cout << "OVERFLOW!!!\n";
                return 0;
            }
        }else if(op == "for"){
            long long x;
            cin >> x;

            long long cur = st.top();
            long long nxt;

            // 先判断再乘，防止乘法本身溢出
            if(cur > LIM / x) nxt = LIM;
            else nxt = cur * x;

            // 超过上限后截断到 LIM 即可，不必保存真实大数
            if(nxt > LIM) nxt = LIM;
            st.push(nxt);
        }else{
            st.pop(); // end：退出当前循环层
        }
    }

    cout << ans << '\n';
    return 0;
}
