# CF1175B · Catch Overflow!

- 难度：1600
- 标签：data structures、expression parsing、implementation
- 链接：https://codeforces.com/problemset/problem/1175/B
- 时间限制：1 second　内存限制：256 megabytes
- 出现位置：Day02-表达式解析-栈-括号序列

## 中文题意

给定一个用某种基础语言写成的函数 $f$。该函数接受一个整数值，并立即写入某个变量 $x$。$x$ 是整型变量，可取 $0$ 到 $2^{32}-1$ 的值。函数包含三类命令：

- `for $n$`——for 循环；
- `end`——`for $n$` 与其对应 `end` 之间的每条命令都会执行 $n$ 次；
- `add`——把 $x$ 加 $1$。

执行完这些命令后返回 $x$ 的值。

每个 `for $n$` 都与一个 `end` 匹配，因此保证函数合法。`for $n$` 后可以紧跟 `end`，`add` 命令也可以位于所有 for 循环之外。

注意 `add` 命令可能使 $x$ 溢出！即某次 `add` 后 $x$ 的值超过 $2^{32}-1$。

现在你运行 $f(0)$，想知道最终 $x$ 的值是否正确，还是发生溢出导致结果错误。若发生溢出，输出 `OVERFLOW!!!`，否则输出 $x$ 的最终值。

## 输入格式（中文）

第一行为单个整数 $l$（$1 \le l \le 10^5$）——函数的行数。

接下来 $l$ 行，每行为以下三类命令之一：

- `for $n$`（$1 \le n \le 100$）——for 循环；
- `end`——`for $n$` 与其对应 `end` 之间的每条命令都会执行 $n$ 次；
- `add`——把 $x$ 加 $1$。

## 输出格式（中文）

若执行 $f(0)$ 过程中发生溢出，输出 `OVERFLOW!!!`，否则输出 $x$ 的最终值。

## 样例

### 样例 1

输入：

```text
9
add
for 43
end
for 10
for 15
add
end
add
end
```

输出：

```text
161
```

### 样例 2

输入：

```text
2
for 62
end
```

输出：

```text
0
```

### 样例 3

输入：

```text
11
for 100
for 100
for 100
for 100
for 100
add
end
end
end
end
end
```

输出：

```text
OVERFLOW!!!
```