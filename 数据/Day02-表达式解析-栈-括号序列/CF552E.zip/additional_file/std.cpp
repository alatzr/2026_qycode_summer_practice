#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

int cnt;                 // 数字个数
ll nums[2600];           // 第 i 个数字（本题都是一位数）
char ops[2600];          // ops[i] 连接 nums[i] 与 nums[i+1]

// 求值只含 + 和 * 的数列：先把连乘合成一项，再把各项相加
ll evalPlain(vector<ll>& vals, vector<char>& link) {
    ll total = 0, term = vals[0];
    for (int i = 0; i < (int)link.size(); i++) {
        if (link[i] == '*') term *= vals[i + 1];
        else { total += term; term = vals[i + 1]; }
    }
    return total + term;
}

// 括号包住数字下标 [ql,qr]，返回整个表达式的值
ll evalWithBracket(int ql, int qr) {
    // 先算括号内部
    vector<ll> innerVals(nums + ql, nums + qr + 1);
    vector<char> innerLink(ops + ql, ops + qr);
    ll inner = evalPlain(innerVals, innerLink);
    // 把括号当成一个数拼回原表达式
    vector<ll> vals;
    vector<char> link;
    for (int i = 0; i < ql; i++) vals.push_back(nums[i]);
    vals.push_back(inner);
    for (int i = qr + 1; i < cnt; i++) vals.push_back(nums[i]);
    for (int i = 0; i < ql; i++) link.push_back(ops[i]);
    for (int i = qr; i < cnt - 1; i++) link.push_back(ops[i]);
    return evalPlain(vals, link);
}

int main() {
    static char expr[5100];
    scanf("%s", expr);
    int len = strlen(expr);
    for (int i = 0; i < len; i++) {
        if (i % 2 == 0) nums[cnt++] = expr[i] - '0';
        else ops[cnt - 1] = expr[i];
    }

    // 左括号只放在开头或某个 * 之后，右括号只放在结尾或某个 * 之前
    vector<int> starts, ends;
    starts.push_back(0);
    ends.push_back(cnt - 1);
    for (int i = 0; i < cnt - 1; i++)
        if (ops[i] == '*') {
            starts.push_back(i + 1);   // * 右边的数字可作括号起点
            ends.push_back(i);         // * 左边的数字可作括号终点
        }

    ll ans = 0;
    for (int st : starts)
        for (int en : ends)
            if (st <= en) ans = max(ans, evalWithBracket(st, en));
    printf("%lld\n", ans);
    return 0;
}
