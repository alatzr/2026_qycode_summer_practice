#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

ll parsePrice(const string& p) {
    int n = p.size(), last = -1;
    for (int i = 0; i < n; i++) if (p[i]=='.') last = i;
    ll cents = 0;
    string dpart = p;
    if (last != -1 && n - last - 1 == 2) {
        cents = (p[last+1]-'0')*10 + (p[last+2]-'0');
        dpart = p.substr(0, last);
    }
    ll dollars = 0;
    for (char c : dpart) if (c != '.') dollars = dollars*10 + (c-'0');
    return dollars*100 + cents;
}

string formatPrice(ll total) {
    ll dollars = total/100, cents = total%100;
    string ds = to_string(dollars);
    string out;
    int n = ds.size();
    for (int i = 0; i < n; i++) {
        if (i && (n-i)%3==0) out += '.';
        out += ds[i];
    }
    if (cents) {
        out += '.';
        if (cents < 10) out += '0';
        out += to_string(cents);
    }
    return out;
}

int main(){
    ios::sync_with_stdio(false); cin.tie(nullptr);
    string s; cin >> s;
    ll sum = 0;
    for (int i = 0; i < (int)s.size(); ) {
        while (i < (int)s.size() && islower(s[i])) i++;
        int j = i;
        while (j < (int)s.size() && (isdigit(s[j]) || s[j]=='.')) j++;
        sum += parsePrice(s.substr(i, j-i));
        i = j;
    }
    cout << formatPrice(sum) << '\n';
}
