#include<bits/stdc++.h>
using namespace std;

bool isleft(char c){
    return c == '(' || c == '[' || c == '{' || c == '<';
}

char need(char c){
    if(c == '(') return ')';
    if(c == '[') return ']';
    if(c == '{') return '}';
    return '>';
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string s;
    cin >> s;

    stack<char> st; // 存还没有匹配的左括号
    int ans = 0;    // 需要替换的右括号数量
    bool ok = true;

    for(char c: s){
        if(isleft(c)){
            st.push(c); // 左括号等待后面的右括号匹配
        }else{
            if(st.empty()){
                ok = false; // 没有左括号能和它匹配
                break;
            }

            char l = st.top();
            st.pop();

            if(need(l) != c){
                ans++; // 结构能匹配，但右括号类型不对，需要替换
            }
        }
    }

    if(!st.empty()) ok = false; // 还有左括号没闭合

    if(!ok) cout << "Impossible\n";
    else cout << ans << '\n';

    return 0;
}
