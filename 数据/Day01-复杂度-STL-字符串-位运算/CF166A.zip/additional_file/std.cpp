#include<bits/stdc++.h>
using namespace std;

struct Node{
    int p, t; // p: 解题数, t: 罚时
};

bool cmp(Node a, Node b){
    if(a.p != b.p) return a.p > b.p; // 解题数多的排前面
    return a.t < b.t;                // 解题数相同，罚时少的排前面
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, k;
    cin >> n >> k;

    vector<Node> a(n + 1); // 1 下标
    for(int i = 1; i <= n; i++) cin >> a[i].p >> a[i].t;

    sort(a.begin() + 1, a.end(), cmp);

    Node key = a[k];
    int ans = 0;
    for(int i = 1; i <= n; i++)
        if(a[i].p == key.p && a[i].t == key.t) ans++;

    cout << ans << '\n';
    return 0;
}
