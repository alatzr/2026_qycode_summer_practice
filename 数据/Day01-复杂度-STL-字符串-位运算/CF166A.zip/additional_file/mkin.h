#!/usr/bin/env python3
# CF166A Rank List 生成器
# 约束：1<=k<=n<=50；1<=p_i,t_i<=50
import os, random
OUT = os.path.join(os.path.dirname(__file__), "inputs")
os.makedirs(OUT, exist_ok=True)

samples = ["7 2\n4 10\n4 10\n4 10\n3 20\n2 1\n2 1\n1 10\n",
           "5 4\n3 1\n3 1\n5 3\n3 1\n3 1\n"]


def build(n, k, teams):
    return f"{n} {k}\n" + "\n".join(f"{p} {t}" for p, t in teams) + "\n"


def rand_case(rng, n, k, pmax, tmax):
    teams = [(rng.randint(1, pmax), rng.randint(1, tmax)) for _ in range(n)]
    return build(n, k, teams)


def main():
    rng = random.Random(166)
    files = list(samples)
    files.append(build(1, 1, [(1, 1)]))                        # 最小
    files.append(build(3, 2, [(5, 5), (5, 5), (5, 5)]))        # 全并列
    files.append(rand_case(rng, 5, 3, 3, 3))                   # 小(对拍)
    files.append(rand_case(rng, 20, 10, 5, 5))                 # 小(对拍)
    files.append(rand_case(rng, 50, 25, 50, 50))               # 满量程随机
    files.append(rand_case(rng, 50, 1, 2, 2))                  # 第1名多并列
    files.append(rand_case(rng, 50, 50, 2, 2))                 # 末名并列
    files.append(build(50, 30, [(3, 3)] * 50))                 # 全相同 -> 50
    for idx, content in enumerate(files, 1):
        with open(os.path.join(OUT, f"{idx}.in"), "w", newline="\n") as fh:
            fh.write(content)
    print(f"CF166A 生成 {len(files)} 个输入")


if __name__ == "__main__":
    main()
