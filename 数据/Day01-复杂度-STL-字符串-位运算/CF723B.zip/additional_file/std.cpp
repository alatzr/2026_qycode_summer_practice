#include<bits/stdc++.h>
using namespace std;

bool isletter(char ch){
    // 单词可能含大小写字母
    return (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z');
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    string s;
    cin >> n >> s;

    bool inside = false; // false 表示括号外，true 表示括号内
    int len = 0;         // 当前连续字母段长度
    int mx = 0;          // 括号外最长单词长度
    int cnt = 0;         // 括号内单词个数

    auto finish = [&](){
        if(len == 0) return; // 没有正在统计的单词，不需要结算

        if(inside) cnt++;         // 括号内：统计单词个数
        else mx = max(mx, len);   // 括号外：更新最长长度

        len = 0;             // 结算后清空当前单词长度
    };

    for(char ch: s){
        if(isletter(ch)){
            len++;           // 字母属于当前单词
        }else{
            finish();        // 分隔符会结束当前单词

            if(ch == '(') inside = true;  // 进入括号
            if(ch == ')') inside = false; // 离开括号
        }
    }

    finish(); // 字符串末尾可能还有一个单词

    cout << mx << ' ' << cnt << '\n';
    return 0;
}
