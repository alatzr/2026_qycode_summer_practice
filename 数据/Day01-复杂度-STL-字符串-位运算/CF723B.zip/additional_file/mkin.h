#!/usr/bin/env python3
# CF723B 数据生成器
# 用法：python3 gen.py <case名> <seed>
# 各 case 用途：
#   single_letter  : n=1 单个字母（最小规模，括号外单词）
#   empty_pair     : n=2 空括号对
#   all_letters    : n=255 全字母（括号外最长单词顶格）
#   one_big_inside : n=255 括号包住 253 个字母（括号内单个超长单词）
#   all_underscore : n=255 全下划线（两个答案均为 0）
#   many_pairs     : 大量 ()a()b 形式的空括号对与单字母单词
#   tight_words    : word(word)word 紧贴括号边界的结构
#   rand_small     : 小随机串（对拍用，n 在 10~40）
#   rand_full      : n=255 随机混合（word 偏重）
#   rand_paren     : n=255 随机混合（括号偏重）
import random
import string
import sys

case_name = sys.argv[1]
seed = int(sys.argv[2])
rng = random.Random(seed)

LETTERS = string.ascii_letters


def random_mix(n, letter_w, under_w, paren_w):
    # 状态机生成：保证括号配对、不嵌套、长度精确为 n
    chars = []
    inside = False
    for i in range(n):
        rem = n - i
        if inside and rem == 1:
            chars.append(')')
            inside = False
            continue
        if inside:
            pick = rng.choices(['L', 'U', ')'], weights=[letter_w, under_w, paren_w])[0]
        else:
            options = ['L', 'U']
            weights = [letter_w, under_w]
            if rem >= 2:
                options.append('(')
                weights.append(paren_w)
            pick = rng.choices(options, weights=weights)[0]
        if pick == 'L':
            chars.append(rng.choice(LETTERS))
        elif pick == 'U':
            chars.append('_')
        elif pick == '(':
            chars.append('(')
            inside = True
        else:
            chars.append(')')
            inside = False
    return ''.join(chars)


def emit(s):
    print(len(s))
    print(s)


if case_name == 'single_letter':
    emit('a' if seed % 2 == 0 else 'Z')
elif case_name == 'empty_pair':
    emit('()')
elif case_name == 'all_letters':
    emit(''.join(rng.choice(LETTERS) for _ in range(255)))
elif case_name == 'one_big_inside':
    emit('(' + ''.join(rng.choice(LETTERS) for _ in range(253)) + ')')
elif case_name == 'all_underscore':
    emit('_' * 255)
elif case_name == 'many_pairs':
    # ()x()x... 空括号对与单字母交替，逼近 255
    parts = []
    total = 0
    while total + 3 <= 255:
        parts.append('()')
        parts.append(rng.choice(LETTERS))
        total += 3
    emit(''.join(parts))
elif case_name == 'tight_words':
    # 形如 word(word)word(word)... 单词紧贴括号
    parts = []
    total = 0
    outside_turn = True
    while total < 246:
        wlen = rng.randint(1, 8)
        word = ''.join(rng.choice(LETTERS) for _ in range(wlen))
        if outside_turn:
            parts.append(word)
            total += wlen
        else:
            parts.append('(' + word + ')')
            total += wlen + 2
        outside_turn = not outside_turn
    emit(''.join(parts))
elif case_name == 'rand_small':
    n = rng.randint(10, 40)
    emit(random_mix(n, 5, 3, 2))
elif case_name == 'rand_full':
    emit(random_mix(255, 8, 2, 1))
elif case_name == 'rand_paren':
    emit(random_mix(255, 3, 2, 5))
else:
    raise SystemExit(f'unknown case {case_name}')
