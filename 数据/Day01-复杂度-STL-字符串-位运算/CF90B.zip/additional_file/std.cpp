#include<bits/stdc++.h>
using namespace std;

const int N = 110;

char a[N][N];
int row[N][26]; // row[i][x]：第 i 行字母 x 出现次数
int col[N][26]; // col[j][x]：第 j 列字母 x 出现次数

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m;
    cin >> n >> m;

    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= m; j++){
            cin >> a[i][j];
            int x = a[i][j] - 'a';
            row[i][x]++;
            col[j][x]++;
        }

    string ans;
    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= m; j++){
            int x = a[i][j] - 'a';
            if(row[i][x] == 1 && col[j][x] == 1) ans += a[i][j];
        }

    cout << ans << '\n';
    return 0;
}
