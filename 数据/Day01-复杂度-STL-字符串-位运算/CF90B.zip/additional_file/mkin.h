#!/usr/bin/env python3
# CF90B African Crossword 生成器
# 约束：1<=n,m<=100；小写字母网格
import os, random
OUT = os.path.join(os.path.dirname(__file__), "inputs")
os.makedirs(OUT, exist_ok=True)

samples = ["3 3\ncba\nbcd\ncbc\n", "5 5\nfcofd\nooedo\nafaoa\nrdcdf\neofsf\n"]


def build(grid):
    n = len(grid); m = len(grid[0])
    return f"{n} {m}\n" + "\n".join(grid) + "\n"


def rand_grid(rng, n, m, alpha):
    return [ "".join(rng.choice(alpha) for _ in range(m)) for _ in range(n) ]


def main():
    rng = random.Random(90)
    files = list(samples)
    files.append("1 1\na\n")                              # 最小，唯一 -> a
    files.append("2 2\naa\naa\n")                         # 全相同 -> 空输出
    files.append(build(rand_grid(rng, 4, 5, "ab")))       # 小(对拍)
    files.append(build(rand_grid(rng, 8, 8, "abc")))      # 小(对拍)
    files.append(build(rand_grid(rng, 20, 20, "abcde")))  # 中(对拍)
    files.append(build(rand_grid(rng, 100, 100, "abcdefghijklmnopqrstuvwxyz")))  # 满量程随机
    files.append(build(["a"*100 for _ in range(100)]))    # 满量程全同 -> 空
    # 满量程：对角线唯一
    grid = []
    for i in range(100):
        row = ["a"]*100
        row[i] = "b"
        grid.append("".join(row))
    files.append(build(grid))
    for idx, content in enumerate(files, 1):
        with open(os.path.join(OUT, f"{idx}.in"), "w", newline="\n") as fh:
            fh.write(content)
    print(f"CF90B 生成 {len(files)} 个输入")


if __name__ == "__main__":
    main()
