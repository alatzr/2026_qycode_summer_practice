# CF90B · African Crossword

- 难度：1100
- 标签：implementation、strings
- 链接：https://codeforces.com/problemset/problem/90/B
- 时间限制：2 seconds　内存限制：256 megabytes
- 出现位置：Day01-复杂度-STL-字符串-位运算

## 英文原题面

### Statement

An African crossword is a rectangular table n × m in size. Each cell of the table contains exactly one letter. This table (it is also referred to as grid) contains some encrypted word that needs to be decoded.
To solve the crossword you should cross out all repeated letters in rows and columns. In other words, a letter should only be crossed out if and only if the corresponding column or row contains at least one more letter that is exactly the same. Besides, all such letters are crossed out simultaneously.
When all repeated letters have been crossed out, we should write the remaining letters in a string. The letters that occupy a higher position follow before the letters that occupy a lower position. If the letters are located in one row, then the letter to the left goes first. The resulting word is the answer to the problem.
You are suggested to solve an African crossword and print the word encrypted there.

### Input

The first line contains two integers n and m (1 ≤ n, m ≤ 100). Next n lines contain m lowercase Latin letters each. That is the crossword grid.

### Output

Print the encrypted word on a single line. It is guaranteed that the answer consists of at least one letter.

## 样例

### 样例 1

输入：

```text
3 3
cba
bcd
cbc
```

输出：

```text
abcd
```

### 样例 2

输入：

```text
5 5
fcofd
ooedo
afaoa
rdcdf
eofsf
```

输出：

```text
codeforces
```