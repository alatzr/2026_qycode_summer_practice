#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    vector<ll> a(n), b(n);
    for(int i = 0; i < n; i++) cin >> a[i];
    for(int i = 0; i < n; i++) cin >> b[i];
    ll f0 = 0, f1 = 0;
    for(int i = 0; i < n; i++){
        ll n0 = max(f1 + a[i], f0);
        ll n1 = max(f0 + b[i], f1);
        f0 = n0; f1 = n1;
    }
    cout << max(f0, f1) << '\n';
    return 0;
}
