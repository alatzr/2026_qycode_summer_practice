#!/usr/bin/env python3
# CF313B 数据生成器
# 用法：python3 gen.py <case名> <seed>
# 各 case 用途：
#   min_same    : n=2 两字符相同（最小规模，答案 1）
#   min_diff    : n=2 两字符不同（最小规模，答案 0）
#   alternating : 交替串 .#.#，任何区间答案为 0
#   rand_small  : 小随机（n,q ≤ 60，供 bf 对拍）
#   blocks      : 长块聚集串（同字符大段），中等规模
#   periodic    : 周期串 n=1e5，如 ..##..## 循环
#   full_same   : n=1e5 全 '.'，q=1e5 全部 [1,n]（最大答案顶格）
#   full_rand   : n=1e5 随机串，q=1e5 随机区间（满量程）
import random
import sys

case_name = sys.argv[1]
seed = int(sys.argv[2])
rng = random.Random(seed)

N_MAX = 100000
Q_MAX = 100000


def rand_queries(n, q):
    lines = []
    for _ in range(q):
        l = rng.randint(1, n - 1)
        r = rng.randint(l + 1, n)
        lines.append(f"{l} {r}")
    return lines


def emit(s, queries):
    print(s)
    print(len(queries))
    print('\n'.join(queries))


if case_name == 'min_same':
    emit('##', ['1 2'])
elif case_name == 'min_diff':
    emit('.#', ['1 2'])
elif case_name == 'alternating':
    n = 99999
    s = ''.join('.' if i % 2 == 0 else '#' for i in range(n))
    emit(s, rand_queries(n, 200))
elif case_name == 'rand_small':
    n = rng.randint(2, 60)
    s = ''.join(rng.choice('.#') for _ in range(n))
    emit(s, rand_queries(n, rng.randint(1, 60)))
elif case_name == 'blocks':
    # 由长度 1~500 的同字符块拼接
    parts = []
    total = 0
    cur = rng.choice('.#')
    while total < 50000:
        blk = rng.randint(1, 500)
        blk = min(blk, 50000 - total)
        parts.append(cur * blk)
        total += blk
        cur = '.' if cur == '#' else '#'
    s = ''.join(parts)
    emit(s, rand_queries(len(s), 5000))
elif case_name == 'periodic':
    unit = '..##'
    s = (unit * (N_MAX // len(unit) + 1))[:N_MAX]
    emit(s, rand_queries(N_MAX, Q_MAX))
elif case_name == 'full_same':
    s = '.' * N_MAX
    queries = [f"1 {N_MAX}"] * Q_MAX
    emit(s, queries)
elif case_name == 'full_rand':
    s = ''.join(rng.choice('.#') for _ in range(N_MAX))
    emit(s, rand_queries(N_MAX, Q_MAX))
else:
    raise SystemExit(f'unknown case {case_name}')
