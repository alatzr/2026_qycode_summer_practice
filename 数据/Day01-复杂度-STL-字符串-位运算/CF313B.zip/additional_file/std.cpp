#include<bits/stdc++.h>
using namespace std;

const int N = 100000 + 10;
int pre[N]; // pre[i] 表示 1..i 中有多少个位置满足 s[j]==s[j+1]

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string s;
    cin >> s;

    int n = (int)s.size();
    s = " " + s; // 转成 1 下标，原来的 s[0] 变成 s[1]

    for(int i = 1; i < n; i++){
        int add = (s[i] == s[i + 1]); // 位置 i 和 i+1 是否相等
        pre[i] = pre[i - 1] + add;
    }

    int q;
    cin >> q;
    while(q--){
        int l, r;
        cin >> l >> r;

        // 只统计左端点 i=l..r-1 的相邻对
        cout << pre[r - 1] - pre[l - 1] << '\n';
    }

    return 0;
}
