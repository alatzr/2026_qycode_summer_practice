#!/usr/bin/env python3
# CF1042B Vitamins 生成器
# 约束：1<=n<=1000；1<=c_i<=1e5；s_i 是 {A,B,C} 的非空子集
import os, random
OUT = os.path.join(os.path.dirname(__file__), "inputs")
os.makedirs(OUT, exist_ok=True)

samples = ["4\n5 C\n6 B\n16 BAC\n4 A\n", "2\n10 AB\n15 BA\n",
           "5\n10 A\n9 BC\n11 CA\n4 A\n5 B\n",
           "6\n100 A\n355 BCA\n150 BC\n160 AC\n180 B\n190 CA\n", "2\n5 BA\n11 CB\n"]

SUBSETS = ["A", "B", "C", "AB", "AC", "BC", "ABC"]


def rand_case(rng, n, cmax):
    lines = [str(n)]
    for _ in range(n):
        lines.append(f"{rng.randint(1, cmax)} {rng.choice(SUBSETS)}")
    return "\n".join(lines) + "\n"


def main():
    rng = random.Random(10420)
    files = list(samples)
    files.append("1\n5 A\n")                          # 单瓶不含全部 -> -1
    files.append("1\n7 ABC\n")                        # 单瓶含全部
    files.append("3\n1 A\n1 B\n1 C\n")                # 三瓶各一
    files.append(rand_case(rng, 10, 100))             # 小(对拍)
    files.append(rand_case(rng, 50, 1000))            # 小(对拍)
    files.append(rand_case(rng, 200, 100000))         # 中(对拍)
    files.append(rand_case(rng, 1000, 100000))        # 满量程随机
    # 满量程：全是单一维生素（大量 -1 风险 / 需三瓶组合）
    lines = ["1000"]
    for i in range(1000): lines.append(f"{rng.randint(1,100000)} {rng.choice(['A','B','C'])}")
    files.append("\n".join(lines) + "\n")
    # 满量程：全部只有 AB（永远缺 C）-> -1
    files.append("1000\n" + "\n".join(f"{rng.randint(1,100000)} AB" for _ in range(1000)) + "\n")
    for idx, content in enumerate(files, 1):
        with open(os.path.join(OUT, f"{idx}.in"), "w", newline="\n") as fh:
            fh.write(content)
    print(f"CF1042B 生成 {len(files)} 个输入")


if __name__ == "__main__":
    main()
