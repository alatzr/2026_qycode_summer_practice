#include<bits/stdc++.h>
using namespace std;

const int INF = 1e9;

int getmask(string s){
    int m = 0;
    for(char c: s){
        if(c == 'A') m |= 1;
        if(c == 'B') m |= 2;
        if(c == 'C') m |= 4;
    }
    return m;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;

    vector<int> cost(8, INF);
    cost[0] = 0;

    for(int i = 1; i <= n; i++){
        int c;
        string s;
        cin >> c >> s;
        int m = getmask(s);
        cost[m] = min(cost[m], c);
    }

    int ans = INF;
    for(int a = 0; a < 8; a++)
        for(int b = 0; b < 8; b++)
            for(int c = 0; c < 8; c++){
                if(cost[a] == INF || cost[b] == INF || cost[c] == INF) continue;
                if((a | b | c) == 7) ans = min(ans, cost[a] + cost[b] + cost[c]);
            }

    if(ans == INF) cout << -1 << '\n';
    else cout << ans << '\n';
    return 0;
}
