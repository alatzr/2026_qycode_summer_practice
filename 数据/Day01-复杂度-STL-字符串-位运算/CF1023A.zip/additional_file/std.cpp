#include<bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m;
    string p, t;
    cin >> n >> m >> p >> t;

    int pos = -1; // 记录 * 的位置；-1 表示没有 *
    for(int i = 0; i < n; i++){
        if(p[i] == '*') pos = i;
    }

    if(pos == -1){
        cout << (p == t ? "YES" : "NO") << '\n';
        return 0;
    }

    string pre = p.substr(0, pos);       // * 左边
    string suf = p.substr(pos + 1);      // * 右边

    if((int)t.size() < (int)pre.size() + (int)suf.size()){
        cout << "NO\n";
        return 0;
    }

    bool ok = true;
    for(int i = 0; i < (int)pre.size(); i++)
        if(t[i] != pre[i]) ok = false;

    int start = (int)t.size() - (int)suf.size();
    for(int i = 0; i < (int)suf.size(); i++)
        if(t[start + i] != suf[i]) ok = false;

    cout << (ok ? "YES" : "NO") << '\n';
    return 0;
}
