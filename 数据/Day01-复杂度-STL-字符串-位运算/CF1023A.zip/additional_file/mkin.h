#!/usr/bin/env python3
# CF1023A Single Wildcard Pattern Matching 生成器
# 约束：1<=n,m<=2e5；s 小写字母+至多一个 '*'；t 小写字母
import os, random
OUT = os.path.join(os.path.dirname(__file__), "inputs")
os.makedirs(OUT, exist_ok=True)

samples = ["6 10\ncode*s\ncodeforces\n", "6 5\nvk*cup\nvkcup\n",
           "1 1\nv\nk\n", "9 6\ngfgf*gfgf\ngfgfgf\n"]


def build(s, t):
    return f"{len(s)} {len(t)}\n{s}\n{t}\n"


def rand_lower(rng, n, alpha):
    return "".join(rng.choice(alpha) for _ in range(n))


def main():
    rng = random.Random(10230)
    files = list(samples)
    files.append(build("a", "a"))                       # 无*相等
    files.append(build("a", "b"))                       # 无*不等
    files.append(build("*", "abcde"))                   # 纯*匹配任意
    files.append(build("*", ""))                        # * 匹配空？t 至少长1，用下例
    files[-1] = build("ab*", "ab")                      # *匹配空
    # 小随机(对拍)：一半带*
    for _ in range(4):
        alpha = "ab"
        if rng.random() < 0.5:
            pre = rand_lower(rng, rng.randint(0, 4), alpha)
            suf = rand_lower(rng, rng.randint(0, 4), alpha)
            s = pre + "*" + suf
        else:
            s = rand_lower(rng, rng.randint(1, 6), alpha)
        t = rand_lower(rng, rng.randint(1, 8), alpha)
        files.append(build(s, t))
    # 匹配成功的大构造：pre + 填充 + suf
    pre = rand_lower(rng, 50000, "abcdefghijklmnopqrstuvwxyz")
    suf = rand_lower(rng, 50000, "abcdefghijklmnopqrstuvwxyz")
    mid = rand_lower(rng, 100000, "abcdefghijklmnopqrstuvwxyz")
    files.append(build(pre + "*" + suf, pre + mid + suf))   # 满量程 YES
    # 满量程 NO：无*且长度接近
    s = rand_lower(rng, 200000, "ab")
    t = s[:-1] + ("a" if s[-1] == 'b' else "b")
    files.append(build(s, t))
    # 满量程：s 带*但 t 太短 -> NO
    files.append(build(rand_lower(rng, 100000, "a") + "*" + rand_lower(rng, 100000, "a"), rand_lower(rng, 5, "a")))
    for idx, content in enumerate(files, 1):
        with open(os.path.join(OUT, f"{idx}.in"), "w", newline="\n") as fh:
            fh.write(content)
    print(f"CF1023A 生成 {len(files)} 个输入")


if __name__ == "__main__":
    main()
