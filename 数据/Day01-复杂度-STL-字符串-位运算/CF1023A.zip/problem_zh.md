# CF1023A · Single Wildcard Pattern Matching

- 难度：1200
- 标签：brute force、implementation、strings
- 链接：https://codeforces.com/problemset/problem/1023/A
- 时间限制：1 second　内存限制：256 megabytes
- 出现位置：Day01-复杂度-STL-字符串-位运算

## 中文题意

给定两个字符串 $s$ 和 $t$。字符串 $s$ 由小写拉丁字母和至多一个通配符 `*` 组成，字符串 $t$ 仅由小写拉丁字母组成。$s$ 的长度为 $n$，$t$ 的长度为 $m$。

$s$ 中的通配符 `*`（若存在）可以被替换为任意（可以为空）的小写拉丁字母序列；$s$ 的其余字符不可改动。若能通过替换 `*` 使 $s$ 变为 $t$，则称 $t$ 与模式 $s$ 匹配。

例如 $s=$"aba*aba" 时，"abaaba"、"abacaba"、"abazzzaba" 都与之匹配，而 "ababa"、"abcaaba"、"codeforces"、"aba1aba"、"aba?aba" 都不匹配。

若给定的 $t$ 与给定的 $s$ 匹配，输出 `YES`，否则输出 `NO`。

## 输入格式（中文）

第一行包含两个整数 $n$ 和 $m$（$1 \le n, m \le 2 \cdot 10^5$）——分别为字符串 $s$ 的长度和字符串 $t$ 的长度。

第二行包含长度为 $n$ 的字符串 $s$，由小写拉丁字母和至多一个通配符 `*` 组成。

第三行包含长度为 $m$ 的字符串 $t$，仅由小写拉丁字母组成。

## 输出格式（中文）

若能由字符串 $s$ 得到字符串 $t$，输出 `YES`，否则输出 `NO`（不含引号，按原文大写输出，区分大小写）。

## 样例

### 样例 1

输入：

```text
6 10
code*s
codeforces
```

输出：

```text
YES
```

### 样例 2

输入：

```text
6 5
vk*cup
vkcup
```

输出：

```text
YES
```

### 样例 3

输入：

```text
1 1
v
k
```

输出：

```text
NO
```

### 样例 4

输入：

```text
9 6
gfgf*gfgf
gfgfgf
```

输出：

```text
NO
```